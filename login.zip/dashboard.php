<?php
session_start();
if (!isset($_SESSION['logged_in'])) {
    header("Location: login.php");
    exit();
}

// Check which page to display
$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';

// Include database for pages that need it
if ($page == 'add_student' || $page == 'view_students' || $page == 'fee_management' || $page == 'dashboard') {
    include 'db.php';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Fee Management</title>
    
    <!-- Chart.js for graphs -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f2f5;
            display: flex;
            min-height: 100vh;
        }
        
        /* ===== SIDEBAR STYLES ===== */
        .sidebar {
            width: 280px;
            min-width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, #1a1f36 0%, #2d3561 100%);
            color: white;
            padding: 0;
            overflow-y: auto;
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            z-index: 1000;
            transition: transform 0.3s ease;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar::-webkit-scrollbar {
            width: 4px;
        }
        .sidebar::-webkit-scrollbar-track {
            background: rgba(255,255,255,0.05);
        }
        .sidebar::-webkit-scrollbar-thumb {
            background: #5469d4;
            border-radius: 10px;
        }
        
        .sidebar-brand {
            padding: 25px 25px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.08);
            margin-bottom: 10px;
        }
        
        .sidebar-brand h4 {
            color: white;
            font-size: 1.3rem;
            font-weight: 700;
            margin: 0;
            letter-spacing: -0.5px;
        }
        
        .sidebar-brand .subtitle {
            color: rgba(255,255,255,0.4);
            font-size: 0.65rem;
            font-weight: 400;
            letter-spacing: 1px;
            text-transform: uppercase;
            margin-top: 4px;
        }
        
        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .sidebar-menu .menu-label {
            padding: 15px 25px 5px;
            color: rgba(255,255,255,0.25);
            font-size: 0.6rem;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            font-weight: 600;
        }
        
        .sidebar-menu li {
            margin-bottom: 1px;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 25px;
            color: rgba(255,255,255,0.6);
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
            font-weight: 500;
            cursor: pointer;
        }
        
        .sidebar-menu a:hover {
            color: white;
            background: rgba(255,255,255,0.05);
            border-left-color: #5469d4;
        }
        
        .sidebar-menu a.active {
            color: white;
            background: rgba(84,105,212,0.15);
            border-left-color: #5469d4;
        }
        
        .sidebar-menu a .icon {
            font-size: 1.1rem;
            width: 24px;
            text-align: center;
        }
        
        .sidebar-menu a .arrow {
            margin-left: auto;
            font-size: 0.7rem;
            color: rgba(255,255,255,0.3);
        }
        
        .sidebar-menu .sub-menu {
            list-style: none;
            padding: 0;
            margin: 0;
            background: rgba(0,0,0,0.15);
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease;
        }
        
        .sidebar-menu .sub-menu.open {
            max-height: 500px;
        }
        
        .sidebar-menu .sub-menu a {
            padding: 10px 25px 10px 65px;
            font-size: 0.85rem;
            color: rgba(255,255,255,0.5);
            border-left: 2px solid transparent;
        }
        
        .sidebar-menu .sub-menu a:hover {
            color: white;
            background: rgba(255,255,255,0.05);
            border-left-color: #5469d4;
        }
        
        .sidebar-menu .sub-menu a.active {
            color: white;
            background: rgba(84,105,212,0.12);
            border-left-color: #5469d4;
        }
        
        .sidebar-menu .sub-menu a .icon {
            font-size: 0.8rem;
            width: 20px;
        }
        
        .sidebar-divider {
            height: 1px;
            margin: 10px 25px;
            background: rgba(255,255,255,0.06);
        }
        
        .sidebar-footer {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 20px 25px;
            border-top: 1px solid rgba(255,255,255,0.08);
            background: rgba(0,0,0,0.1);
        }
        
        .sidebar-footer .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .sidebar-footer .avatar {
            width: 40px;
            height: 40px;
            background: #5469d4;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 1rem;
            flex-shrink: 0;
        }
        
        .sidebar-footer .user-details {
            flex: 1;
            min-width: 0;
        }
        
        .sidebar-footer .user-name {
            color: white;
            font-size: 0.9rem;
            font-weight: 600;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .sidebar-footer .user-email {
            color: rgba(255,255,255,0.4);
            font-size: 0.75rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .sidebar-footer .logout-btn {
            color: rgba(255,255,255,0.3);
            transition: color 0.3s ease;
            font-size: 1.2rem;
            text-decoration: none;
            padding: 5px;
        }
        
        .sidebar-footer .logout-btn:hover {
            color: #dc3545;
        }
        
        /* ===== MAIN CONTENT AREA ===== */
        .main-content {
            margin-left: 280px;
            width: calc(100% - 280px);
            min-height: 100vh;
            padding: 30px;
            background: #f0f2f5;
        }
        
        .content-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 30px;
            min-height: 600px;
        }
        
        .content-card .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f2f5;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .content-card .header h2 {
            font-weight: 600;
            color: #1a1f36;
            margin: 0;
        }
        
        .content-card .header .breadcrumb {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        /* ===== FORM STYLES ===== */
        .form-group {
            margin-bottom: 20px;
            position: relative;
        }
        
        .form-group label {
            display: block;
            font-weight: 600;
            color: #1a1f36;
            margin-bottom: 5px;
            font-size: 0.9rem;
        }
        
        .form-group label .required {
            color: #dc3545;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px 14px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            font-family: inherit;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #5469d4;
            box-shadow: 0 0 0 3px rgba(84,105,212,0.1);
        }
        
        .form-group input.error {
            border-color: #dc3545;
            background: #fff8f8;
        }
        
        .form-group input.success {
            border-color: #28a745;
            background: #f8fff8;
        }
        
        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .form-row-3 {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 20px;
        }
        
        /* ===== EMAIL VALIDATION STYLES ===== */
        .email-validation-icon {
            position: absolute;
            right: 15px;
            top: 42px;
            font-size: 1.2rem;
        }
        
        .email-validation-icon.loading {
            color: #ffc107;
            animation: spin 1s linear infinite;
        }
        
        .email-validation-icon.valid {
            color: #28a745;
        }
        
        .email-validation-icon.invalid {
            color: #dc3545;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .email-error-message {
            color: #dc3545;
            font-size: 0.85rem;
            margin-top: 5px;
            display: none;
            font-weight: 500;
        }
        
        .email-error-message.show {
            display: block;
        }
        
        .email-success-message {
            color: #28a745;
            font-size: 0.85rem;
            margin-top: 5px;
            display: none;
            font-weight: 500;
        }
        
        .email-success-message.show {
            display: block;
        }
        
        .btn-submit {
            background: #5469d4;
            color: white;
            padding: 12px 35px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-submit:hover:not(:disabled) {
            background: #3f55b8;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(84,105,212,0.3);
        }
        
        .btn-submit:disabled {
            background: #6c757d;
            cursor: not-allowed;
            opacity: 0.6;
        }
        
        .btn-reset {
            background: #6c757d;
            color: white;
            padding: 12px 35px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-reset:hover {
            background: #5a6268;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        /* ===== DASHBOARD PLACEHOLDER ===== */
        .dashboard-placeholder {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 500px;
        }
        
        .dashboard-placeholder .icon {
            font-size: 4rem;
            color: #5469d4;
            margin-bottom: 20px;
            opacity: 0.3;
        }
        
        .dashboard-placeholder h2 {
            color: #1a1f36;
            font-weight: 300;
            margin-bottom: 10px;
        }
        
        .dashboard-placeholder p {
            color: #6c757d;
            font-size: 1rem;
        }
        
        .quick-actions {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: center;
            margin-top: 20px;
        }
        
        .quick-actions a {
            padding: 12px 25px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .quick-actions a:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        
        .btn-primary {
            background: #5469d4;
            color: white;
        }
        
        .btn-success {
            background: #28a745;
            color: white;
        }
        
        .btn-warning {
            background: #ffc107;
            color: #1a1f36;
        }
        
        /* ===== MOBILE TOGGLE ===== */
        .mobile-toggle {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: #1a1f36;
            color: white;
            border: none;
            padding: 12px 16px;
            border-radius: 8px;
            font-size: 1.5rem;
            cursor: pointer;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
        }
        
        .mobile-toggle:hover {
            background: #2d3561;
        }
        
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }
        
        .sidebar-overlay.show {
            display: block;
        }
        
        /* ===== DASHBOARD CONTENT STYLES - MOBILE RESPONSIVE ===== */
        .dashboard-content-wrapper {
            padding: 0;
        }
        
        .dashboard-content-wrapper .content-card {
            background: transparent;
            box-shadow: none;
            padding: 0;
            min-height: auto;
        }
        
        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-box {
            background: white;
            padding: 20px 25px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border-left: 4px solid #5469d4;
            transition: all 0.3s ease;
        }
        
        .stat-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .stat-box .stat-icon {
            font-size: 1.8rem;
            margin-bottom: 8px;
        }
        
        .stat-box .stat-label {
            font-size: 0.8rem;
            color: #6c757d;
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        
        .stat-box .stat-value {
            font-size: 1.8rem;
            font-weight: 700;
            color: #1a1f36;
        }
        
        .stat-box .stat-sub {
            font-size: 0.8rem;
            color: #6c757d;
            margin-top: 5px;
        }
        
        .stat-box.green { border-left-color: #28a745; }
        .stat-box.blue { border-left-color: #5469d4; }
        .stat-box.orange { border-left-color: #fd7e14; }
        .stat-box.red { border-left-color: #dc3545; }
        .stat-box.purple { border-left-color: #6f42c1; }
        .stat-box.teal { border-left-color: #20c997; }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 25px;
            margin-bottom: 30px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .dashboard-card .card-title {
            font-size: 1rem;
            font-weight: 600;
            color: #1a1f36;
            margin-bottom: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .dashboard-card .card-title .badge-count {
            background: #5469d4;
            color: white;
            padding: 2px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
        }
        
        .chart-container {
            position: relative;
            height: 280px;
            width: 100%;
        }
        
        .filter-section {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
            margin-bottom: 20px;
            padding: 15px 20px;
            background: #f8f9fa;
            border-radius: 12px;
        }
        
        .filter-section label {
            font-weight: 600;
            font-size: 0.9rem;
            color: #1a1f36;
            margin: 0;
        }
        
        .filter-section select {
            padding: 8px 14px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 0.9rem;
            background: white;
            transition: all 0.3s ease;
        }
        
        .filter-section select:focus {
            outline: none;
            border-color: #5469d4;
        }
        
        .filter-section .btn-filter {
            background: #5469d4;
            color: white;
            padding: 8px 25px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .filter-section .btn-filter:hover {
            background: #3f55b8;
        }
        
        .pending-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.85rem;
        }
        
        .pending-table th {
            background: #f8f9fa;
            padding: 10px 12px;
            text-align: left;
            border-bottom: 2px solid #e9ecef;
            font-weight: 600;
            white-space: nowrap;
        }
        
        .pending-table td {
            padding: 10px 12px;
            border-bottom: 1px solid #e9ecef;
        }
        
        .pending-table tr:hover {
            background: #f8f9fa;
        }
        
        .pending-badge {
            background: #dc3545;
            color: white;
            padding: 2px 10px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        
        .status-badge {
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
            display: inline-block;
        }
        
        .status-badge.paid { background: #d4edda; color: #155724; }
        .status-badge.pending { background: #fff3cd; color: #856404; }
        .status-badge.partial { background: #cce5ff; color: #004085; }
        .status-badge.overdue { background: #f8d7da; color: #721c24; }
        
        .recent-payments-list {
            max-height: 400px;
            overflow-y: auto;
        }
        
        .recent-payments-list::-webkit-scrollbar {
            width: 4px;
        }
        .recent-payments-list::-webkit-scrollbar-thumb {
            background: #5469d4;
            border-radius: 10px;
        }
        
        .payment-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #f0f2f5;
            flex-wrap: wrap;
            gap: 5px;
        }
        
        .payment-item:last-child {
            border-bottom: none;
        }
        
        .payment-item .student-name {
            font-weight: 600;
            color: #1a1f36;
        }
        
        .payment-item .student-id {
            font-size: 0.75rem;
            color: #6c757d;
        }
        
        .payment-item .amount {
            font-weight: 700;
            color: #28a745;
        }
        
        .payment-item .date {
            font-size: 0.75rem;
            color: #6c757d;
        }
        
        .payment-method-badge {
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.65rem;
            background: #e9ecef;
            color: #495057;
        }
        
        .btn-view-all {
            color: #5469d4;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.85rem;
        }
        
        .btn-view-all:hover {
            text-decoration: underline;
        }
        
        .no-data {
            text-align: center;
            padding: 30px;
            color: #6c757d;
        }
        
        .no-data .icon {
            font-size: 3rem;
            opacity: 0.3;
            margin-bottom: 10px;
        }
        
        .btn-view {
            color: #5469d4;
            text-decoration: none;
            font-weight: 600;
        }
        
        /* ===== QUICK ACTION BUTTONS ===== */
        .quick-action-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .quick-action-btn {
            background: white;
            padding: 20px 15px;
            border-radius: 12px;
            text-align: center;
            text-decoration: none;
            color: #1a1f36;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            border: 1px solid #e9ecef;
        }
        
        .quick-action-btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border-color: #5469d4;
        }
        
        .quick-action-btn .icon {
            font-size: 2rem;
            margin-bottom: 8px;
            display: block;
        }
        
        .quick-action-btn .label {
            font-size: 0.75rem;
            font-weight: 600;
            color: #1a1f36;
        }
        
        /* ===== RESPONSIVE STYLES ===== */
        @media (max-width: 1200px) {
            .dashboard-stats {
                grid-template-columns: repeat(3, 1fr);
            }
        }
        
        @media (max-width: 992px) {
            .sidebar {
                width: 280px;
                transform: translateX(-100%);
                position: fixed;
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .mobile-toggle {
                display: block;
            }
            
            .main-content {
                margin-left: 0;
                width: 100%;
                padding: 80px 20px 20px;
            }
            
            .form-row,
            .form-row-3 {
                grid-template-columns: 1fr;
            }
            
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
            
            .dashboard-stats {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .quick-action-grid {
                grid-template-columns: repeat(3, 1fr);
            }
        }
        
        @media (max-width: 768px) {
            .dashboard-stats {
                grid-template-columns: 1fr 1fr;
                gap: 12px;
            }
            
            .stat-box {
                padding: 15px;
            }
            
            .stat-box .stat-value {
                font-size: 1.3rem;
            }
            
            .stat-box .stat-icon {
                font-size: 1.3rem;
            }
            
            .filter-section {
                flex-direction: column;
                align-items: stretch;
                padding: 15px;
            }
            
            .filter-section select {
                width: 100%;
            }
            
            .filter-section .btn-filter {
                width: 100%;
            }
            
            .filter-section span {
                margin-left: 0 !important;
                text-align: center;
            }
            
            .dashboard-card {
                padding: 15px;
            }
            
            .chart-container {
                height: 200px;
            }
            
            .content-card {
                padding: 15px;
            }
            
            .quick-action-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 10px;
            }
            
            .quick-action-btn {
                padding: 15px 10px;
            }
            
            .quick-action-btn .icon {
                font-size: 1.5rem;
            }
            
            .pending-table {
                font-size: 0.75rem;
            }
            
            .pending-table th,
            .pending-table td {
                padding: 6px 8px;
            }
            
            .payment-item {
                flex-direction: column;
                align-items: flex-start;
                padding: 8px 0;
            }
            
            .payment-item .amount {
                font-size: 0.9rem;
            }
            
            .dashboard-card .card-title {
                font-size: 0.9rem;
            }
            
            .dashboard-card .card-title .badge-count {
                font-size: 0.65rem;
                padding: 2px 8px;
            }
        }
        
        @media (max-width: 576px) {
            .sidebar {
                width: 260px;
            }
            
            .main-content {
                padding: 70px 10px 10px;
            }
            
            .content-card {
                padding: 10px;
            }
            
            .dashboard-stats {
                grid-template-columns: 1fr 1fr;
                gap: 8px;
            }
            
            .stat-box {
                padding: 12px;
            }
            
            .stat-box .stat-value {
                font-size: 1.1rem;
            }
            
            .stat-box .stat-label {
                font-size: 0.65rem;
            }
            
            .stat-box .stat-sub {
                font-size: 0.65rem;
            }
            
            .stat-box .stat-icon {
                font-size: 1.1rem;
                margin-bottom: 4px;
            }
            
            .quick-action-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 8px;
            }
            
            .quick-action-btn {
                padding: 12px 8px;
            }
            
            .quick-action-btn .icon {
                font-size: 1.3rem;
                margin-bottom: 4px;
            }
            
            .quick-action-btn .label {
                font-size: 0.65rem;
            }
            
            .chart-container {
                height: 180px;
            }
            
            .dashboard-card {
                padding: 10px;
            }
            
            .dashboard-card .card-title {
                font-size: 0.8rem;
            }
            
            .pending-table {
                font-size: 0.65rem;
            }
            
            .pending-table th,
            .pending-table td {
                padding: 4px 6px;
            }
            
            .payment-item .student-name {
                font-size: 0.85rem;
            }
            
            .payment-item .amount {
                font-size: 0.8rem;
            }
            
            .mobile-toggle {
                top: 10px;
                left: 10px;
                padding: 10px 12px;
                font-size: 1.2rem;
            }
        }
        
        /* ===== SCROLLBAR STYLES ===== */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #5469d4;
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: #3f55b8;
        }
    </style>
</head>
<body>

<!-- ===== MOBILE TOGGLE ===== -->
<button class="mobile-toggle" id="mobileToggle" aria-label="Toggle Sidebar">☰</button>
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<!-- ===== SIDEBAR ===== -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-brand">
        <h4>Fee Management</h4>
        <div class="subtitle">System v2.0</div>
    </div>
    
    <ul class="sidebar-menu">
        <li>
            <a href="dashboard.php?page=dashboard" class="<?php echo $page == 'dashboard' ? 'active' : ''; ?>">
                <span class="icon">📊</span> Dashboard
            </a>
        </li>
        
        <li class="sidebar-divider"></li>
        
        <li class="menu-label">Student Management</li>
        <li>
            <a href="dashboard.php?page=add_student" class="<?php echo $page == 'add_student' ? 'active' : ''; ?>">
                <span class="icon">➕</span> Add Student
            </a>
        </li>
        <li>
            <a href="dashboard.php?page=view_students" class="<?php echo $page == 'view_students' ? 'active' : ''; ?>">
                <span class="icon">👥</span> View Students
            </a>
        </li>
        
        <li class="sidebar-divider"></li>
        
        <li class="menu-label">Fee Management</li>
        <li>
            <a href="dashboard.php?page=fee_management" class="<?php echo $page == 'fee_management' ? 'active' : ''; ?>">
                <span class="icon">💰</span> Fee Management
            </a>
        </li>
        
        <li class="sidebar-divider"></li>
        
        <li class="menu-label">Fee Processing</li>
        <li>
            <a href="#" onclick="toggleSubMenu2(event)">
                <span class="icon">💳</span> Fee Processing
                <span class="arrow">▶</span>
            </a>
            <ul class="sub-menu" id="feeProcessingSubMenu">
                <li><a href="dashboard.php?page=collect_fee"><span class="icon">🤝</span> Collect Fee</a></li>
                <li><a href="dashboard.php?page=payment_history"><span class="icon">📜</span> Payment History</a></li>
            </ul>
        </li>
        
        <li class="sidebar-divider"></li>
        
        <li class="menu-label">Reports</li>
        <li>
            <a href="dashboard.php?page=reports">
                <span class="icon">📈</span> Reports
            </a>
        </li>
        
        <li class="sidebar-divider"></li>
        
        <li class="menu-label">System</li>
        <li>
            <a href="dashboard.php?page=settings">
                <span class="icon">⚙️</span> Settings
            </a>
        </li>
    </ul>
    
    <div class="sidebar-footer">
        <div class="user-info">
            <div class="avatar">HA</div>
            <div class="user-details">
                <div class="user-name">Hamza</div>
                <div class="user-email">admin@feesystem.com</div>
            </div>
            <a href="logout.php" class="logout-btn" title="Logout">🚪Logout</a>
        </div>
    </div>
</div>

<!-- ===== MAIN CONTENT ===== -->
<div class="main-content">
    <div class="content-card">
        <?php if ($page == 'add_student'): ?>
            <?php include 'add_student_content.php'; ?>
            
        <?php elseif ($page == 'view_students'): ?>
            <?php include 'view_students.php'; ?>
            
        <?php elseif ($page == 'fee_management'): ?>
            <?php include 'fee_management_content.php'; ?>
            
        <?php elseif ($page == 'dashboard'): ?>
            <!-- ===== DASHBOARD CONTENT ===== -->
            <div class="dashboard-content-wrapper">
                <?php 
                // Get current academic year
                $current_year_query = "SELECT * FROM academic_years WHERE is_current = 1 AND status = 'active'";
                $current_year_result = mysqli_query($conn, $current_year_query);
                $current_year = mysqli_fetch_assoc($current_year_result);
                $academic_year_id = $current_year ? $current_year['id'] : 1;

                // Get filter parameters
                $filter_month = isset($_GET['filter_month']) ? (int)$_GET['filter_month'] : date('m');
                $filter_year = isset($_GET['filter_year']) ? (int)$_GET['filter_year'] : date('Y');

                // ===== STATISTICS =====
                // 1. Total Students
                $total_students_query = "SELECT COUNT(*) as total FROM students WHERE status = 'active'";
                $total_students_result = mysqli_query($conn, $total_students_query);
                $total_students = mysqli_fetch_assoc($total_students_result)['total'];

                // 2. Total Collected
                $total_collected_query = "SELECT SUM(amount) as total FROM payments WHERE status = 'completed'";
                $total_collected_result = mysqli_query($conn, $total_collected_query);
                $total_collected = mysqli_fetch_assoc($total_collected_result)['total'] ?? 0;

                // 3. This Month Collected
                $this_month_collected_query = "SELECT SUM(amount) as total FROM payments 
                                               WHERE MONTH(payment_date) = '$filter_month' 
                                               AND YEAR(payment_date) = '$filter_year' 
                                               AND status = 'completed'";
                $this_month_collected_result = mysqli_query($conn, $this_month_collected_query);
                $this_month_collected = mysqli_fetch_assoc($this_month_collected_result)['total'] ?? 0;

                // 4. This Month Pending
                $all_students_query = "SELECT id, fee, admission_date FROM students WHERE status = 'active'";
                $all_students_result = mysqli_query($conn, $all_students_query);
                
                $this_month_pending = 0;
                while($student = mysqli_fetch_assoc($all_students_result)) {
                    $student_id = $student['id'];
                    $monthly_fee = $student['fee'];
                    
                    $paid_query = "SELECT SUM(paid_amount) as paid, SUM(remaining_amount) as remaining, status 
                                   FROM student_fees 
                                   WHERE student_id = '$student_id' 
                                   AND month = '$filter_month' 
                                   AND year = '$filter_year' 
                                   AND academic_year_id = '$academic_year_id'";
                    $paid_result = mysqli_query($conn, $paid_query);
                    $paid_data = mysqli_fetch_assoc($paid_result);
                    
                    if ($paid_data && $paid_data['status'] == 'paid') {
                        continue;
                    } else if ($paid_data && $paid_data['remaining'] > 0) {
                        $this_month_pending += $paid_data['remaining'];
                    } else {
                        $admission_date = $student['admission_date'];
                        $admission_month = date('m', strtotime($admission_date));
                        $admission_year = date('Y', strtotime($admission_date));
                        
                        if ($filter_year > $admission_year || ($filter_year == $admission_year && $filter_month >= $admission_month)) {
                            $this_month_pending += $monthly_fee;
                        }
                    }
                }

                // 5. Total Pending
                $pending_fees_query = "SELECT SUM(remaining_amount) as total FROM student_fees WHERE status IN ('pending', 'partial', 'overdue')";
                $pending_fees_result = mysqli_query($conn, $pending_fees_query);
                $pending_from_table = mysqli_fetch_assoc($pending_fees_result)['total'] ?? 0;
                
                $all_students_query2 = "SELECT s.id, s.fee, s.admission_date FROM students s WHERE s.status = 'active'";
                $all_students_result2 = mysqli_query($conn, $all_students_query2);
                
                $no_record_pending = 0;
                while($student = mysqli_fetch_assoc($all_students_result2)) {
                    $check_query = "SELECT COUNT(*) as count FROM student_fees WHERE student_id = '{$student['id']}' AND academic_year_id = '$academic_year_id'";
                    $check_result = mysqli_query($conn, $check_query);
                    $check_data = mysqli_fetch_assoc($check_result);
                    
                    if ($check_data['count'] == 0) {
                        $admission_date = $student['admission_date'];
                        $admission_month = date('m', strtotime($admission_date));
                        $admission_year = date('Y', strtotime($admission_date));
                        $current_month = date('m');
                        $current_year = date('Y');
                        
                        $months = 0;
                        $year = $admission_year;
                        $month = $admission_month;
                        while ($year < $current_year || ($year == $current_year && $month <= $current_month)) {
                            $months++;
                            $month++;
                            if ($month > 12) {
                                $month = 1;
                                $year++;
                            }
                        }
                        $no_record_pending += $student['fee'] * $months;
                    }
                }
                
                $total_pending = $pending_from_table + $no_record_pending;
                $collection_rate = ($total_collected + $total_pending) > 0 ? ($total_collected / ($total_collected + $total_pending)) * 100 : 0;

                // 6. Students with 3+ months pending
                $three_months_pending_query = "SELECT s.id, s.student_id, s.first_name, s.last_name, s.class, s.fee,
                                               COUNT(sf.id) as pending_months,
                                               SUM(sf.remaining_amount) as total_pending
                                               FROM students s
                                               JOIN student_fees sf ON s.id = sf.student_id
                                               WHERE s.status = 'active' 
                                               AND sf.academic_year_id = '$academic_year_id'
                                               AND sf.status IN ('pending', 'partial', 'overdue')
                                               GROUP BY s.id
                                               HAVING pending_months >= 3
                                               ORDER BY pending_months DESC";
                $three_months_pending_result = mysqli_query($conn, $three_months_pending_query);

                // 7. Monthly Collection Data
                $monthly_collection_data = [];
                for ($i = 11; $i >= 0; $i--) {
                    $month = date('m', strtotime("-$i months"));
                    $year = date('Y', strtotime("-$i months"));
                    $month_name = date('M', strtotime("-$i months"));
                    
                    $query = "SELECT SUM(amount) as total FROM payments 
                              WHERE MONTH(payment_date) = '$month' 
                              AND YEAR(payment_date) = '$year' 
                              AND status = 'completed'";
                    $result = mysqli_query($conn, $query);
                    $amount = mysqli_fetch_assoc($result)['total'] ?? 0;
                    
                    $monthly_collection_data[] = [
                        'month' => $month_name . ' ' . $year,
                        'amount' => (float)$amount
                    ];
                }

                // 8. Class Distribution
                $class_distribution_query = "SELECT class, COUNT(*) as count FROM students WHERE status = 'active' GROUP BY class ORDER BY class";
                $class_distribution_result = mysqli_query($conn, $class_distribution_query);
                $class_distribution = [];
                while($row = mysqli_fetch_assoc($class_distribution_result)) {
                    $class_distribution[] = $row;
                }

                // 9. Payment Methods
                $payment_method_query = "SELECT payment_method, COUNT(*) as count, SUM(amount) as total 
                                         FROM payments WHERE status = 'completed' 
                                         GROUP BY payment_method";
                $payment_method_result = mysqli_query($conn, $payment_method_query);
                $payment_methods = [];
                while($row = mysqli_fetch_assoc($payment_method_result)) {
                    $payment_methods[] = $row;
                }

                // 10. Recent Payments
                $recent_payments_query = "SELECT p.*, s.first_name, s.last_name, s.student_id 
                                          FROM payments p 
                                          JOIN students s ON p.student_id = s.id 
                                          WHERE p.status = 'completed' 
                                          ORDER BY p.payment_date DESC LIMIT 10";
                $recent_payments_result = mysqli_query($conn, $recent_payments_query);

                // 11. Yearly Collection
                $yearly_collection = [];
                for ($m = 1; $m <= 12; $m++) {
                    $query = "SELECT SUM(amount) as total FROM payments 
                              WHERE MONTH(payment_date) = '$m' 
                              AND YEAR(payment_date) = '$filter_year' 
                              AND status = 'completed'";
                    $result = mysqli_query($conn, $query);
                    $amount = mysqli_fetch_assoc($result)['total'] ?? 0;
                    $yearly_collection[] = [
                        'month' => date('M', mktime(0,0,0,$m,1)),
                        'amount' => (float)$amount
                    ];
                }

                // 12. Fee Status
                $fee_status_query = "SELECT 
                                      COUNT(CASE WHEN status = 'paid' THEN 1 END) as paid,
                                      COUNT(CASE WHEN status = 'partial' THEN 1 END) as partial,
                                      COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
                                      COUNT(CASE WHEN status = 'overdue' THEN 1 END) as overdue
                                      FROM student_fees
                                      WHERE month = '$filter_month' 
                                      AND year = '$filter_year'
                                      AND academic_year_id = '$academic_year_id'";
                $fee_status_result = mysqli_query($conn, $fee_status_query);
                $fee_status = mysqli_fetch_assoc($fee_status_result);
                ?>
                
                <!-- ===== FILTER SECTION ===== -->
                <div class="filter-section">
                    <label>📅 Filter by Month:</label>
                    <select name="filter_month" id="filterMonth">
                        <option value="1" <?php echo $filter_month == 1 ? 'selected' : ''; ?>>January</option>
                        <option value="2" <?php echo $filter_month == 2 ? 'selected' : ''; ?>>February</option>
                        <option value="3" <?php echo $filter_month == 3 ? 'selected' : ''; ?>>March</option>
                        <option value="4" <?php echo $filter_month == 4 ? 'selected' : ''; ?>>April</option>
                        <option value="5" <?php echo $filter_month == 5 ? 'selected' : ''; ?>>May</option>
                        <option value="6" <?php echo $filter_month == 6 ? 'selected' : ''; ?>>June</option>
                        <option value="7" <?php echo $filter_month == 7 ? 'selected' : ''; ?>>July</option>
                        <option value="8" <?php echo $filter_month == 8 ? 'selected' : ''; ?>>August</option>
                        <option value="9" <?php echo $filter_month == 9 ? 'selected' : ''; ?>>September</option>
                        <option value="10" <?php echo $filter_month == 10 ? 'selected' : ''; ?>>October</option>
                        <option value="11" <?php echo $filter_month == 11 ? 'selected' : ''; ?>>November</option>
                        <option value="12" <?php echo $filter_month == 12 ? 'selected' : ''; ?>>December</option>
                    </select>
                    
                    <select name="filter_year" id="filterYear">
                        <option value="<?php echo date('Y'); ?>" <?php echo $filter_year == date('Y') ? 'selected' : ''; ?>><?php echo date('Y'); ?></option>
                        <option value="<?php echo date('Y')-1; ?>" <?php echo $filter_year == date('Y')-1 ? 'selected' : ''; ?>><?php echo date('Y')-1; ?></option>
                        <option value="<?php echo date('Y')-2; ?>" <?php echo $filter_year == date('Y')-2 ? 'selected' : ''; ?>><?php echo date('Y')-2; ?></option>
                    </select>
                    
                    <button class="btn-filter" onclick="applyFilter()">Apply Filter</button>
                    <span style="font-size: 0.85rem; color: #6c757d; margin-left: auto;">
                        Showing data for: <strong><?php echo date('F', mktime(0,0,0,$filter_month,1)) . ' ' . $filter_year; ?></strong>
                    </span>
                </div>
                
                <!-- ===== QUICK ACTION BUTTONS ===== -->
                <div class="quick-action-grid">
                    <a href="dashboard.php?page=add_student" class="quick-action-btn">
                        <span class="icon">➕</span>
                        <span class="label">Add Student</span>
                    </a>
                    <a href="dashboard.php?page=view_students" class="quick-action-btn">
                        <span class="icon">👥</span>
                        <span class="label">View Students</span>
                    </a>
                    <a href="dashboard.php?page=fee_management" class="quick-action-btn">
                        <span class="icon">💰</span>
                        <span class="label">Collect Fee</span>
                    </a>
                   
                </div>
                
                <!-- ===== STATISTICS CARDS ===== -->
                <div class="dashboard-stats">
                    <div class="stat-box blue">
                        <div class="stat-icon">👨‍🎓</div>
                        <div class="stat-label">Total Students</div>
                        <div class="stat-value"><?php echo $total_students; ?></div>
                        <div class="stat-sub">Active students</div>
                    </div>
                    
                    <div class="stat-box green">
                        <div class="stat-icon">💰</div>
                        <div class="stat-label">Total Collected</div>
                        <div class="stat-value">Rs. <?php echo number_format($total_collected, 2); ?></div>
                        <div class="stat-sub">All time collection</div>
                    </div>
                    
                    <div class="stat-box orange">
                        <div class="stat-icon">📊</div>
                        <div class="stat-label">This Month Collected</div>
                        <div class="stat-value">Rs. <?php echo number_format($this_month_collected, 2); ?></div>
                        <div class="stat-sub"><?php echo date('F Y', mktime(0,0,0,$filter_month,1,$filter_year)); ?></div>
                    </div>
                    
                    <div class="stat-box red">
                        <div class="stat-icon">⏳</div>
                        <div class="stat-label">This Month Pending</div>
                        <div class="stat-value">Rs. <?php echo number_format($this_month_pending, 2); ?></div>
                        <div class="stat-sub"><?php echo date('F Y', mktime(0,0,0,$filter_month,1,$filter_year)); ?></div>
                    </div>
                    
                    <div class="stat-box purple">
                        <div class="stat-icon">🏷️</div>
                        <div class="stat-label">Total Pending</div>
                        <div class="stat-value">Rs. <?php echo number_format($total_pending, 2); ?></div>
                        <div class="stat-sub">All time pending fees</div>
                    </div>
                    
                    <div class="stat-box teal">
                        <div class="stat-icon">📈</div>
                        <div class="stat-label">Collection Rate</div>
                        <div class="stat-value"><?php echo number_format($collection_rate, 1); ?>%</div>
                        <div class="stat-sub">Overall collection rate</div>
                    </div>
                </div>
                
                <!-- ===== DASHBOARD GRID ===== -->
                <div class="dashboard-grid">
                    <div class="dashboard-card">
                        <div class="card-title">
                            <span>📊 Monthly Collection Trend</span>
                            <span class="badge-count">Last 12 months</span>
                        </div>
                        <div class="chart-container">
                            <canvas id="monthlyChart"></canvas>
                        </div>
                    </div>
                    
                    <div class="dashboard-card">
                        <div class="card-title">
                            <span>📚 Class Distribution</span>
                            <span class="badge-count"><?php echo count($class_distribution); ?> classes</span>
                        </div>
                        <div class="chart-container">
                            <canvas id="classChart"></canvas>
                        </div>
                    </div>
                </div>
                
                <!-- ===== SECOND ROW ===== -->
                <div class="dashboard-grid">
                    <div class="dashboard-card">
                        <div class="card-title">
                            <span>📋 Fee Status - <?php echo date('F Y', mktime(0,0,0,$filter_month,1,$filter_year)); ?></span>
                        </div>
                        <div style="height: 250px;">
                            <canvas id="feeStatusChart"></canvas>
                        </div>
                    </div>
                    
                    <div class="dashboard-card">
                        <div class="card-title">
                            <span>💳 Payment Methods</span>
                            <span class="badge-count"><?php echo count($payment_methods); ?> methods</span>
                        </div>
                        <div style="height: 250px;">
                            <canvas id="paymentMethodChart"></canvas>
                        </div>
                    </div>
                </div>
                
                <!-- ===== YEARLY COLLECTION CHART ===== -->
                <div class="dashboard-card" style="margin-bottom: 30px;">
                    <div class="card-title">
                        <span>📈 Yearly Collection - <?php echo $filter_year; ?></span>
                        <span class="badge-count">Monthly breakdown</span>
                    </div>
                    <div class="chart-container" style="height: 250px;">
                        <canvas id="yearlyChart"></canvas>
                    </div>
                </div>
                
                <!-- ===== THREE MONTHS PENDING STUDENTS ===== -->
                <div class="dashboard-card" style="margin-bottom: 30px;">
                    <div class="card-title">
                        <span>⚠️ Students with 3+ Months Pending</span>
                        <span class="badge-count" style="background: #dc3545;">
                            <?php echo mysqli_num_rows($three_months_pending_result); ?> students
                        </span>
                    </div>
                    
                    <?php if (mysqli_num_rows($three_months_pending_result) > 0): ?>
                        <div class="table-responsive">
                            <table class="pending-table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Student ID</th>
                                        <th>Student Name</th>
                                        <th>Class</th>
                                        <th>Monthly Fee</th>
                                        <th>Pending Months</th>
                                        <th>Total Pending</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $count = 1; ?>
                                    <?php while($student = mysqli_fetch_assoc($three_months_pending_result)): ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td><strong><?php echo htmlspecialchars($student['student_id']); ?></strong></td>
                                            <td><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></td>
                                            <td>Class <?php echo htmlspecialchars($student['class']); ?></td>
                                            <td>Rs. <?php echo number_format($student['fee'], 2); ?></td>
                                            <td><span class="pending-badge"><?php echo $student['pending_months']; ?> months</span></td>
                                            <td style="color: #dc3545; font-weight: 600;">
                                                Rs. <?php echo number_format($student['total_pending'], 2); ?>
                                            </td>
                                            <td>
                                                <a href="dashboard.php?page=fee_management&view_student=<?php echo $student['id']; ?>" class="btn-view" style="font-size: 0.8rem;">
                                                    👁️ View
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="no-data">
                            <div class="icon">🎉</div>
                            <p>No students with 3+ months pending! All caught up!</p>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- ===== RECENT PAYMENTS ===== -->
                <div class="dashboard-card">
                    <div class="card-title">
                        <span>🔄 Recent Payments</span>
                        <a href="dashboard.php?page=payment_history" class="btn-view-all">View All →</a>
                    </div>
                    
                    <?php if (mysqli_num_rows($recent_payments_result) > 0): ?>
                        <div class="recent-payments-list">
                            <?php while($payment = mysqli_fetch_assoc($recent_payments_result)): ?>
                                <div class="payment-item">
                                    <div>
                                        <div class="student-name">
                                            <?php echo htmlspecialchars($payment['first_name'] . ' ' . $payment['last_name']); ?>
                                        </div>
                                        <div class="student-id">
                                            <?php echo htmlspecialchars($payment['student_id']); ?> • 
                                            <span class="payment-method-badge"><?php echo ucfirst($payment['payment_method']); ?></span>
                                        </div>
                                    </div>
                                    <div style="text-align: right;">
                                        <div class="amount">+Rs. <?php echo number_format($payment['amount'], 2); ?></div>
                                        <div class="date"><?php echo date('d-M-Y', strtotime($payment['payment_date'])); ?></div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <div class="no-data">
                            <div class="icon">📭</div>
                            <p>No recent payments found.</p>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- ===== CHARTS JAVASCRIPT ===== -->
                <script>
                function applyFilter() {
                    const month = document.getElementById('filterMonth').value;
                    const year = document.getElementById('filterYear').value;
                    window.location.href = 'dashboard.php?page=dashboard&filter_month=' + month + '&filter_year=' + year;
                }
                
                document.addEventListener('DOMContentLoaded', function() {
                    // Monthly Collection Chart
                    const monthlyCtx = document.getElementById('monthlyChart').getContext('2d');
                    const monthlyData = <?php echo json_encode($monthly_collection_data); ?>;
                    new Chart(monthlyCtx, {
                        type: 'bar',
                        data: {
                            labels: monthlyData.map(d => d.month),
                            datasets: [{
                                label: 'Collection (Rs.)',
                                data: monthlyData.map(d => d.amount),
                                backgroundColor: 'rgba(84, 105, 212, 0.7)',
                                borderColor: 'rgba(84, 105, 212, 1)',
                                borderWidth: 2,
                                borderRadius: 4
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: { legend: { display: false } },
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    ticks: { callback: function(value) { return 'Rs. ' + value.toLocaleString(); } }
                                }
                            }
                        }
                    });
                    
                    // Class Distribution Chart
                    const classCtx = document.getElementById('classChart').getContext('2d');
                    const classData = <?php echo json_encode($class_distribution); ?>;
                    const classColors = ['#5469d4', '#28a745', '#fd7e14', '#dc3545', '#6f42c1', '#20c997', '#ffc107', '#17a2b8', '#e83e8c', '#6c757d'];
                    new Chart(classCtx, {
                        type: 'doughnut',
                        data: {
                            labels: classData.map(d => d.class),
                            datasets: [{ data: classData.map(d => d.count), backgroundColor: classColors.slice(0, classData.length), borderWidth: 0 }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: { position: 'right', labels: { font: { size: 10 } } }
                            }
                        }
                    });
                    
                    // Fee Status Chart
                    const statusCtx = document.getElementById('feeStatusChart').getContext('2d');
                    const statusData = <?php echo json_encode($fee_status); ?>;
                    new Chart(statusCtx, {
                        type: 'bar',
                        data: {
                            labels: ['Paid', 'Partial', 'Pending', 'Overdue'],
                            datasets: [{
                                label: 'Students',
                                data: [statusData.paid || 0, statusData.partial || 0, statusData.pending || 0, statusData.overdue || 0],
                                backgroundColor: ['#28a745', '#ffc107', '#fd7e14', '#dc3545'],
                                borderColor: ['#28a745', '#ffc107', '#fd7e14', '#dc3545'],
                                borderWidth: 2,
                                borderRadius: 4
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: { legend: { display: false } },
                            scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
                        }
                    });
                    
                    // Payment Methods Chart
                    const methodCtx = document.getElementById('paymentMethodChart').getContext('2d');
                    const methodData = <?php echo json_encode($payment_methods); ?>;
                    const methodColors = ['#5469d4', '#28a745', '#fd7e14', '#6f42c1', '#20c997'];
                    new Chart(methodCtx, {
                        type: 'pie',
                        data: {
                            labels: methodData.map(d => d.payment_method.charAt(0).toUpperCase() + d.payment_method.slice(1)),
                            datasets: [{
                                data: methodData.map(d => d.total),
                                backgroundColor: methodColors.slice(0, methodData.length),
                                borderWidth: 0
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: { position: 'right', labels: { font: { size: 10 } } }
                            }
                        }
                    });
                    
                    // Yearly Collection Chart
                    const yearlyCtx = document.getElementById('yearlyChart').getContext('2d');
                    const yearlyData = <?php echo json_encode($yearly_collection); ?>;
                    new Chart(yearlyCtx, {
                        type: 'line',
                        data: {
                            labels: yearlyData.map(d => d.month),
                            datasets: [{
                                label: 'Collection (Rs.)',
                                data: yearlyData.map(d => d.amount),
                                backgroundColor: 'rgba(84, 105, 212, 0.1)',
                                borderColor: 'rgba(84, 105, 212, 1)',
                                borderWidth: 3,
                                fill: true,
                                tension: 0.4,
                                pointBackgroundColor: 'rgba(84, 105, 212, 1)',
                                pointRadius: 4
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: { legend: { display: false } },
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    ticks: { callback: function(value) { return 'Rs. ' + value.toLocaleString(); } }
                                }
                            }
                        }
                    });
                });
                </script>
            </div>
            
        <?php else: ?>
            <!-- ===== DASHBOARD PLACEHOLDER ===== -->
            <div class="dashboard-placeholder">
                <div class="icon">📋</div>
                <h2>Welcome to Fee Management System</h2>
                <p>Your content will appear here. Start adding students, managing fees, and tracking payments.</p>
                
                <div class="quick-actions">
                    <a href="dashboard.php?page=add_student" class="btn-primary">➕ Add Student</a>
                    <a href="dashboard.php?page=view_students" class="btn-success">👥 View Students</a>
                    <a href="dashboard.php?page=fee_management" class="btn-warning">💰 Fee Management</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    function toggleSubMenu(event) {
        event.preventDefault();
        const subMenu = document.getElementById('feeSubMenu');
        const arrow = event.currentTarget.querySelector('.arrow');
        subMenu.classList.toggle('open');
        arrow.textContent = subMenu.classList.contains('open') ? '▼' : '▶';
    }
    
    function toggleSubMenu2(event) {
        event.preventDefault();
        const subMenu = document.getElementById('feeProcessingSubMenu');
        const arrow = event.currentTarget.querySelector('.arrow');
        subMenu.classList.toggle('open');
        arrow.textContent = subMenu.classList.contains('open') ? '▼' : '▶';
    }
    
    document.addEventListener('DOMContentLoaded', function() {
        const sidebar = document.getElementById('sidebar');
        const toggleBtn = document.getElementById('mobileToggle');
        const overlay = document.getElementById('sidebarOverlay');
        
        function toggleSidebar() {
            sidebar.classList.toggle('open');
            overlay.classList.toggle('show');
            document.body.style.overflow = sidebar.classList.contains('open') ? 'hidden' : '';
        }
        
        if (toggleBtn) {
            toggleBtn.addEventListener('click', toggleSidebar);
        }
        
        if (overlay) {
            overlay.addEventListener('click', toggleSidebar);
        }
        
        window.addEventListener('resize', function() {
            if (window.innerWidth > 992 && sidebar.classList.contains('open')) {
                sidebar.classList.remove('open');
                overlay.classList.remove('show');
                document.body.style.overflow = '';
            }
        });
        
        document.querySelectorAll('.sub-menu a').forEach(link => {
            if (link.classList.contains('active')) {
                const parent = link.closest('.sub-menu');
                if (parent) {
                    parent.classList.add('open');
                    const parentLink = parent.parentElement.querySelector('.sidebar-menu > li > a');
                    if (parentLink) {
                        const arrow = parentLink.querySelector('.arrow');
                        if (arrow) arrow.textContent = '▼';
                    }
                }
            }
        });
    });
</script>

</body>
</html>