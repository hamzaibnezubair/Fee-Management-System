<?php
// fee_management_content.php - Fee Management System (CORRECT LOGIC)

// Get current academic year
$current_year_query = "SELECT * FROM academic_years WHERE is_current = 1 AND status = 'active'";
$current_year_result = mysqli_query($conn, $current_year_query);
$current_year = mysqli_fetch_assoc($current_year_result);
$academic_year_id = $current_year ? $current_year['id'] : 1;

// Get classes for filter
$classes_query = "SELECT DISTINCT class FROM students WHERE status = 'active' ORDER BY class";
$classes_result = mysqli_query($conn, $classes_query);

// Get selected class filter
$selected_class = isset($_GET['class_filter']) ? mysqli_real_escape_string($conn, $_GET['class_filter']) : '';

// Get search query
$search_query = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// Get students based on class filter and search
$students_query = "SELECT id, student_id, first_name, last_name, class, admission_date, fee 
                   FROM students WHERE status = 'active'";
if ($selected_class) {
    $students_query .= " AND class = '$selected_class'";
}
if ($search_query) {
    $students_query .= " AND (first_name LIKE '%$search_query%' OR last_name LIKE '%$search_query%' OR student_id LIKE '%$search_query%')";
}
$students_query .= " ORDER BY first_name";
$students_result = mysqli_query($conn, $students_query);

// Handle Fee Submission
$fee_success = '';
$fee_error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_fee'])) {
    $student_id = mysqli_real_escape_string($conn, $_POST['student_id']);
    $month = mysqli_real_escape_string($conn, $_POST['month']);
    $year = mysqli_real_escape_string($conn, $_POST['year']);
    $amount_paid = mysqli_real_escape_string($conn, $_POST['amount_paid']);
    $payment_method = mysqli_real_escape_string($conn, $_POST['payment_method']);
    $received_by = mysqli_real_escape_string($conn, $_POST['received_by']);
    $payment_date = mysqli_real_escape_string($conn, $_POST['payment_date']);
    $notes = mysqli_real_escape_string($conn, $_POST['notes']);
    
    // Get student details
    $student_query = "SELECT id, fee, admission_date FROM students WHERE id = '$student_id'";
    $student_result = mysqli_query($conn, $student_query);
    $student_data = mysqli_fetch_assoc($student_result);
    $student_fee = $student_data['fee'];
    $admission_date = $student_data['admission_date'];
    
    $admission_month = date('m', strtotime($admission_date));
    $admission_year = date('Y', strtotime($admission_date));
    
    $month_number = (int)$month;
    $year_number = (int)$year;
    
    // ===== CHECK 1: Is this month before admission? =====
    if ($year_number < $admission_year || ($year_number == $admission_year && $month_number < $admission_month)) {
        $fee_error = "❌ This month is before admission date (" . date('M Y', strtotime($admission_date)) . ")!";
    } 
    // ===== CHECK 2: Is this month in the future? =====
    elseif ($year_number > date('Y') || ($year_number == date('Y') && $month_number > date('m'))) {
        $fee_error = "❌ Cannot collect fee for future months!";
    }
    else {
        // ===== CHECK 3: Check if this specific month is already paid =====
        $check_sql = "SELECT * FROM student_fees 
                      WHERE student_id = '$student_id' 
                      AND month = '$month' 
                      AND year = '$year' 
                      AND academic_year_id = '$academic_year_id'";
        $check_result = mysqli_query($conn, $check_sql);
        
        if (mysqli_num_rows($check_result) > 0) {
            $fee_record = mysqli_fetch_assoc($check_result);
            
            // ===== CHECK 4: Is this month already paid? =====
            if ($fee_record['status'] == 'paid') {
                $fee_error = "❌ Fee for " . date('F', mktime(0,0,0,$month,1)) . " " . $year . " is already paid!";
            } else {
                // ===== Update this month's record to paid =====
                $update_sql = "UPDATE student_fees SET 
                    paid_amount = total_amount,
                    remaining_amount = 0,
                    status = 'paid',
                    payment_date = '$payment_date'
                    WHERE id = '{$fee_record['id']}'";
                
                if (mysqli_query($conn, $update_sql)) {
                    $receipt_number = 'RCP' . date('Y') . str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT);
                    
                    $payment_sql = "INSERT INTO payments (
                        student_fee_id, student_id, amount, payment_method, 
                        receipt_number, received_by, payment_date, notes
                    ) VALUES (
                        '{$fee_record['id']}', '$student_id', '{$fee_record['total_amount']}', '$payment_method',
                        '$receipt_number', '$received_by', '$payment_date', '$notes'
                    )";
                    
                    if (mysqli_query($conn, $payment_sql)) {
                        $fee_success = "✅ Fee for " . date('F', mktime(0,0,0,$month,1)) . " " . $year . " submitted! Receipt: " . $receipt_number;
                    }
                }
            }
        } else {
            // ===== No record exists for this month - Create it =====
            // But first check if this month is valid (between admission and current)
            $total_months_from_admission = 0;
            $year = $admission_year;
            $month = $admission_month;
            while ($year < $year_number || ($year == $year_number && $month <= $month_number)) {
                $total_months_from_admission++;
                $month++;
                if ($month > 12) {
                    $month = 1;
                    $year++;
                }
            }
            
            if ($total_months_from_admission <= 0) {
                $fee_error = "❌ Invalid month selection!";
            } else {
                $total_amount = $student_fee;
                $due_date = date('Y-m-d', strtotime("$year_number-$month_number-20"));
                
                $insert_sql = "INSERT INTO student_fees (
                    student_id, academic_year_id, month, year,
                    total_amount, paid_amount, remaining_amount, due_date, status, payment_date
                ) VALUES (
                    '$student_id', '$academic_year_id', '$month_number', '$year_number',
                    '$total_amount', '$total_amount', 0, 
                    '$due_date', 'paid', '$payment_date'
                )";
                
                if (mysqli_query($conn, $insert_sql)) {
                    $fee_id = mysqli_insert_id($conn);
                    $receipt_number = 'RCP' . date('Y') . str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT);
                    
                    $payment_sql = "INSERT INTO payments (
                        student_fee_id, student_id, amount, payment_method, 
                        receipt_number, received_by, payment_date, notes
                    ) VALUES (
                        '$fee_id', '$student_id', '$total_amount', '$payment_method',
                        '$receipt_number', '$received_by', '$payment_date', '$notes'
                    )";
                    
                    if (mysqli_query($conn, $payment_sql)) {
                        $fee_success = "✅ Fee for " . date('F', mktime(0,0,0,$month_number,1)) . " " . $year_number . " submitted! Receipt: " . $receipt_number;
                    }
                }
            }
        }
    }
}

// Get student fee summary
$summary_student_id = isset($_GET['view_student']) ? mysqli_real_escape_string($conn, $_GET['view_student']) : '';

// Get all students with correct fee calculations
$all_students_summary = [];
if (!isset($_GET['view_student'])) {
    $students_all_query = "SELECT s.id, s.student_id, s.first_name, s.last_name, s.class, s.fee, s.admission_date
                          FROM students s
                          WHERE s.status = 'active'";
    if ($selected_class) {
        $students_all_query .= " AND s.class = '$selected_class'";
    }
    if ($search_query) {
        $students_all_query .= " AND (s.first_name LIKE '%$search_query%' OR s.last_name LIKE '%$search_query%' OR s.student_id LIKE '%$search_query%')";
    }
    $students_all_query .= " ORDER BY s.first_name";
    
    $students_all_result = mysqli_query($conn, $students_all_query);
    
    while($student = mysqli_fetch_assoc($students_all_result)) {
        // ===== CALCULATE TOTAL MONTHS FROM ADMISSION TO CURRENT =====
        $admission_date = $student['admission_date'];
        $admission_month = date('m', strtotime($admission_date));
        $admission_year = date('Y', strtotime($admission_date));
        $current_month = date('m');
        $current_year = date('Y');
        
        $total_months = 0;
        $year = $admission_year;
        $month = $admission_month;
        while ($year < $current_year || ($year == $current_year && $month <= $current_month)) {
            $total_months++;
            $month++;
            if ($month > 12) {
                $month = 1;
                $year++;
            }
        }
        
        // ===== GET PAID MONTHS =====
        $paid_query = "SELECT COUNT(*) as paid_count FROM student_fees 
                       WHERE student_id = '{$student['id']}' 
                       AND academic_year_id = '$academic_year_id'
                       AND status = 'paid'";
        $paid_result = mysqli_query($conn, $paid_query);
        $paid_data = mysqli_fetch_assoc($paid_result);
        $paid_months = $paid_data['paid_count'];
        
        // ===== CALCULATE PENDING MONTHS =====
        $pending_months = $total_months - $paid_months;
        $total_pending_amount = $student['fee'] * $pending_months;
        $total_paid_amount = $student['fee'] * $paid_months;
        
        $student['total_months'] = $total_months;
        $student['paid_months'] = $paid_months;
        $student['pending_months'] = $pending_months;
        $student['total_paid'] = $total_paid_amount;
        $student['total_pending'] = $total_pending_amount;
        $student['monthly_fee'] = $student['fee'];
        
        $all_students_summary[] = $student;
    }
}

// Calculate totals
$total_students = count($all_students_summary);
$total_collected = array_sum(array_column($all_students_summary, 'total_paid'));
$total_pending_amount = array_sum(array_column($all_students_summary, 'total_pending'));
$pending_students_count = 0;
foreach ($all_students_summary as $student) {
    if ($student['total_pending'] > 0) {
        $pending_students_count++;
    }
}

// Get individual student fee records
$fee_records = [];
$student_info = [];
if ($summary_student_id) {
    $info_query = "SELECT * FROM students WHERE id = '$summary_student_id' AND status = 'active'";
    $info_result = mysqli_query($conn, $info_query);
    $student_info = mysqli_fetch_assoc($info_result);
    
    if ($student_info) {
        $records_query = "SELECT sf.*, p.receipt_number, p.payment_method, p.amount as payment_amount
                          FROM student_fees sf
                          LEFT JOIN payments p ON sf.id = p.student_fee_id
                          WHERE sf.student_id = '$summary_student_id' 
                          AND sf.academic_year_id = '$academic_year_id'
                          ORDER BY sf.year DESC, sf.month DESC";
        $records_result = mysqli_query($conn, $records_query);
        while($row = mysqli_fetch_assoc($records_result)) {
            $fee_records[] = $row;
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <style>
        * { box-sizing: border-box; }
        
        .fee-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .fee-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 25px;
        }
        
        .stat-card {
            background: #f8f9fa;
            padding: 15px 20px;
            border-radius: 10px;
            border-left: 4px solid #5469d4;
        }
        
        .stat-card .label {
            font-size: 0.8rem;
            color: #6c757d;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .stat-card .value {
            font-size: 1.5rem;
            font-weight: 700;
            color: #1a1f36;
        }
        
        .stat-card .value.green { color: #28a745; }
        .stat-card .value.red { color: #dc3545; }
        .stat-card .value.blue { color: #5469d4; }
        .stat-card .value.orange { color: #fd7e14; }
        
        .fee-form {
            background: #f8f9fa;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 30px;
            border: 2px solid #e9ecef;
        }
        
        .fee-form .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 15px;
        }
        
        .fee-form .form-row-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        .fee-form .form-row-3 {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 15px;
        }
        
        .fee-form .filter-row {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
            flex-wrap: wrap;
            align-items: flex-end;
        }
        
        .fee-form .filter-row .class-filter {
            min-width: 180px;
        }
        
        .fee-form .filter-row .class-filter label {
            font-size: 0.85rem;
            display: block;
            font-weight: 600;
            color: #1a1f36;
            margin-bottom: 5px;
        }
        
        .fee-form .filter-row .class-filter select {
            width: 100%;
            padding: 10px 14px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 0.9rem;
            background: white;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: inherit;
        }
        
        .fee-form .filter-row .class-filter select:focus {
            outline: none;
            border-color: #5469d4;
            box-shadow: 0 0 0 3px rgba(84,105,212,0.1);
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #5469d4;
            box-shadow: 0 0 0 3px rgba(84,105,212,0.1);
        }
        
        .fee-table-wrapper {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
            background: white;
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
        }
        
        .table-header .left-section {
            display: flex;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }
        
        .table-header .left-section h5 {
            margin: 0;
            font-size: 1.1rem;
            color: #1a1f36;
        }
        
        .table-header .left-section .results-count {
            color: #6c757d;
            font-size: 0.85rem;
            background: #f8f9fa;
            padding: 4px 12px;
            border-radius: 20px;
        }
        
        .search-box {
            display: flex;
            gap: 10px;
            align-items: center;
            background: #fff;
            padding: 4px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
            min-width: 250px;
            flex-wrap: wrap;
        }
        
        .search-box:hover {
            border-color: #5469d4;
            box-shadow: 0 2px 12px rgba(84,105,212,0.15);
        }
        
        .search-box:focus-within {
            border-color: #5469d4;
            box-shadow: 0 2px 12px rgba(84,105,212,0.15);
        }
        
        .search-box .search-icon {
            color: #6c757d;
            font-size: 1.1rem;
            margin-left: 10px;
        }
        
        .search-box input {
            border: none;
            outline: none;
            padding: 10px 0;
            font-size: 0.95rem;
            flex: 1;
            min-width: 120px;
            background: transparent;
            color: #1a1f36;
            font-family: inherit;
        }
        
        .search-box input::placeholder {
            color: #adb5bd;
        }
        
        .search-box .btn-search {
            background: #5469d4;
            color: white;
            padding: 10px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            white-space: nowrap;
        }
        
        .search-box .btn-search:hover {
            background: #3f55b8;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(84,105,212,0.3);
        }
        
        .search-box .btn-clear {
            background: #dc3545;
            color: white;
            padding: 10px 18px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.9rem;
            text-decoration: none;
            transition: all 0.3s ease;
            white-space: nowrap;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        
        .search-box .btn-clear:hover {
            background: #c82333;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(220,53,69,0.3);
        }
        
        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        
        .fee-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
            min-width: 800px;
        }
        
        .fee-table th {
            background: #f8f9fa;
            padding: 12px 15px;
            text-align: left;
            border-bottom: 2px solid #e9ecef;
            font-weight: 600;
            white-space: nowrap;
        }
        
        .fee-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #e9ecef;
        }
        
        .fee-table tr:hover {
            background: #f8f9fa;
        }
        
        .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-block;
        }
        
        .status-badge.paid { background: #d4edda; color: #155724; }
        .status-badge.pending { background: #fff3cd; color: #856404; }
        .status-badge.partial { background: #cce5ff; color: #004085; }
        .status-badge.overdue { background: #f8d7da; color: #721c24; }
        
        .btn-view {
            background: #5469d4;
            color: white;
            padding: 6px 14px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.85rem;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }
        
        .btn-view:hover {
            background: #3f55b8;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(84,105,212,0.3);
        }
        
        .btn-back {
            background: #6c757d;
            color: white;
            padding: 6px 14px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.85rem;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-back:hover {
            background: #5a6268;
        }
        
        .pending-badge {
            background: #dc3545;
            color: white;
            padding: 2px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-block;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .student-info {
            background: #e7f3ff;
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #5469d4;
        }
        
        .student-info strong {
            color: #004085;
        }
        
        .btn-submit {
            background: #5469d4;
            color: white;
            padding: 12px 35px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-submit:hover {
            background: #3f55b8;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(84,105,212,0.3);
        }
        
        .btn-reset {
            background: #6c757d;
            color: white;
            padding: 12px 35px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-left: 10px;
        }
        
        .btn-reset:hover {
            background: #5a6268;
        }
        
        @media (max-width: 992px) {
            .fee-form .form-row,
            .fee-form .form-row-3 {
                grid-template-columns: 1fr 1fr;
            }
            
            .fee-stats {
                grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            }
        }
        
        @media (max-width: 768px) {
            .fee-form .form-row,
            .fee-form .form-row-2,
            .fee-form .form-row-3 {
                grid-template-columns: 1fr;
            }
            
            .fee-form .filter-row {
                flex-direction: column;
                align-items: stretch;
            }
            
            .fee-form .filter-row .class-filter {
                min-width: 100%;
            }
            
            .fee-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .table-header {
                flex-direction: column;
                align-items: stretch;
                padding: 15px;
            }
            
            .table-header .left-section {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .table-header .left-section h5 {
                font-size: 1rem;
            }
            
            .search-box {
                min-width: 100%;
                flex-wrap: wrap;
                padding: 8px;
            }
            
            .search-box .search-icon {
                display: none;
            }
            
            .search-box input {
                min-width: 100%;
                padding: 10px 14px;
                border: 1px solid #e9ecef;
                border-radius: 6px;
                background: #f8f9fa;
                font-size: 0.9rem;
                width: 100%;
            }
            
            .search-box .btn-search,
            .search-box .btn-clear {
                flex: 1;
                text-align: center;
                justify-content: center;
                padding: 10px 15px;
                font-size: 0.85rem;
                min-width: 0;
            }
            
            .fee-table-wrapper {
                padding: 10px;
                border-radius: 8px;
            }
            
            .table-responsive {
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                margin: 0 -10px;
                padding: 0 10px;
            }
            
            .fee-table {
                font-size: 0.8rem;
                min-width: 700px;
            }
            
            .fee-table th,
            .fee-table td {
                padding: 8px 10px;
                white-space: nowrap;
            }
            
            .fee-stats {
                grid-template-columns: 1fr 1fr;
                gap: 10px;
            }
            
            .stat-card {
                padding: 12px 15px;
            }
            
            .stat-card .value {
                font-size: 1.2rem;
            }
            
            .stat-card .label {
                font-size: 0.7rem;
            }
        }
        
        @media (max-width: 480px) {
            .fee-stats {
                grid-template-columns: 1fr;
            }
            
            .fee-form {
                padding: 15px;
            }
            
            .fee-table-wrapper {
                padding: 5px;
            }
            
            .fee-table {
                font-size: 0.7rem;
                min-width: 600px;
            }
            
            .fee-table th,
            .fee-table td {
                padding: 6px 8px;
            }
            
            .stat-card .value {
                font-size: 1rem;
            }
            
            .btn-submit,
            .btn-reset {
                width: 100%;
                margin-left: 0;
                margin-top: 10px;
                text-align: center;
                padding: 12px 20px;
            }
            
            .student-info {
                padding: 10px 15px;
                font-size: 0.85rem;
            }
            
            .table-header .left-section .results-count {
                font-size: 0.75rem;
            }
        }
    </style>
</head>
<body>
    <div class="fee-header">
        <div>
            <h2>💰 Fee Management</h2>
            <div class="breadcrumb">Fee Management / Collect & View Fees</div>
        </div>
    </div>
    
    <?php if ($fee_success): ?>
        <div class="alert alert-success"><?php echo $fee_success; ?></div>
    <?php endif; ?>
    
    <?php if ($fee_error): ?>
        <div class="alert alert-danger"><?php echo $fee_error; ?></div>
    <?php endif; ?>
    
    <!-- Statistics -->
    <?php if (!$summary_student_id && !empty($all_students_summary)): ?>
        <div class="fee-stats">
            <div class="stat-card">
                <div class="label">Total Students</div>
                <div class="value blue"><?php echo $total_students; ?></div>
            </div>
            <div class="stat-card">
                <div class="label">Total Collected</div>
                <div class="value green">RS. <?php echo number_format($total_collected, 2); ?></div>
            </div>
            <div class="stat-card">
                <div class="label">Total Pending</div>
                <div class="value red">RS. <?php echo number_format($total_pending_amount, 2); ?></div>
            </div>
            <div class="stat-card">
                <div class="label">Pending Students</div>
                <div class="value orange"><?php echo $pending_students_count; ?></div>
            </div>
        </div>
    <?php endif; ?>
    
    <!-- Fee Collection Form -->
    <div class="fee-form">
        <h5 style="margin-bottom: 15px; color: #1a1f36;">📝 Collect Fee</h5>
        
        <form method="GET" action="dashboard.php" class="filter-row" id="filterForm">
            <input type="hidden" name="page" value="fee_management">
            
            <div class="class-filter">
                <label>Filter by Class:</label>
                <select name="class_filter" onchange="this.form.submit()">
                    <option value="">All Classes</option>
                    <?php 
                    mysqli_data_seek($classes_result, 0);
                    while($class_row = mysqli_fetch_assoc($classes_result)): 
                    ?>
                        <option value="<?php echo htmlspecialchars($class_row['class']); ?>" <?php echo $selected_class == $class_row['class'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($class_row['class']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
        </form>
        
        <form method="POST" action="dashboard.php?page=fee_management" id="feeForm">
            <div class="form-row">
                <div class="form-group" style="margin-bottom: 0;">
                    <label style="font-size: 0.85rem; display: block; font-weight: 600; color: #1a1f36; margin-bottom: 5px;">Select Student <span style="color: #dc3545;">*</span></label>
                    <select name="student_id" id="studentSelect" required style="width: 100%; padding: 10px 14px; border: 2px solid #e9ecef; border-radius: 8px; font-size: 0.9rem; background: white; transition: all 0.3s ease; font-family: inherit;">
                        <option value="">Select Student</option>
                        <?php 
                        mysqli_data_seek($students_result, 0);
                        while($student = mysqli_fetch_assoc($students_result)): 
                        ?>
                            <option value="<?php echo $student['id']; ?>" data-fee="<?php echo $student['fee']; ?>" data-admission="<?php echo $student['admission_date']; ?>">
                                <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name'] . ' (' . $student['student_id'] . ') - Class ' . $student['class'] . ' - Fee: RS. ' . number_format($student['fee'], 2)); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label style="font-size: 0.85rem; display: block; font-weight: 600; color: #1a1f36; margin-bottom: 5px;">Month <span style="color: #dc3545;">*</span></label>
                    <select name="month" id="monthSelect" required style="width: 100%; padding: 10px 14px; border: 2px solid #e9ecef; border-radius: 8px; font-size: 0.9rem; background: white; transition: all 0.3s ease; font-family: inherit;">
                        <option value="">Select Month</option>
                        <option value="1">January</option>
                        <option value="2">February</option>
                        <option value="3">March</option>
                        <option value="4">April</option>
                        <option value="5">May</option>
                        <option value="6">June</option>
                        <option value="7">July</option>
                        <option value="8">August</option>
                        <option value="9">September</option>
                        <option value="10">October</option>
                        <option value="11">November</option>
                        <option value="12">December</option>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label style="font-size: 0.85rem; display: block; font-weight: 600; color: #1a1f36; margin-bottom: 5px;">Year <span style="color: #dc3545;">*</span></label>
                    <select name="year" id="yearSelect" required style="width: 100%; padding: 10px 14px; border: 2px solid #e9ecef; border-radius: 8px; font-size: 0.9rem; background: white; transition: all 0.3s ease; font-family: inherit;">
                        <option value="">Select Year</option>
                        <option value="<?php echo date('Y'); ?>"><?php echo date('Y'); ?></option>
                        <option value="<?php echo date('Y')-1; ?>"><?php echo date('Y')-1; ?></option>
                    </select>
                </div>
            </div>
            
            <div class="form-row-2" style="margin-top: 15px;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label style="font-size: 0.85rem; display: block; font-weight: 600; color: #1a1f36; margin-bottom: 5px;">Amount Paid <span style="color: #dc3545;">*</span></label>
                    <input type="number" name="amount_paid" id="amountPaid" placeholder="Enter amount" step="0.01" required style="width: 100%; padding: 10px 14px; border: 2px solid #e9ecef; border-radius: 8px; font-size: 0.9rem; transition: all 0.3s ease; font-family: inherit;">
                    <small style="color: #6c757d; font-size: 0.8rem; display: block; margin-top: 4px;" id="feeInfo"></small>
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label style="font-size: 0.85rem; display: block; font-weight: 600; color: #1a1f36; margin-bottom: 5px;">Payment Method <span style="color: #dc3545;">*</span></label>
                    <select name="payment_method" required style="width: 100%; padding: 10px 14px; border: 2px solid #e9ecef; border-radius: 8px; font-size: 0.9rem; background: white; transition: all 0.3s ease; font-family: inherit;">
                        <option value="">Select Method</option>
                        <option value="cash">Cash</option>
                        <option value="bank_transfer">Bank Transfer</option>
                        <option value="online">Online</option>
                        <option value="cheque">Cheque</option>
                    </select>
                </div>
            </div>
            
            <div class="form-row-3" style="margin-top: 15px;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label style="font-size: 0.85rem; display: block; font-weight: 600; color: #1a1f36; margin-bottom: 5px;">Payment Date <span style="color: #dc3545;">*</span></label>
                    <input type="date" name="payment_date" id="paymentDate" value="<?php echo date('Y-m-d'); ?>" required style="width: 100%; padding: 10px 14px; border: 2px solid #e9ecef; border-radius: 8px; font-size: 0.9rem; transition: all 0.3s ease; font-family: inherit;">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label style="font-size: 0.85rem; display: block; font-weight: 600; color: #1a1f36; margin-bottom: 5px;">Received By</label>
                    <input type="text" name="received_by" placeholder="Your name" style="width: 100%; padding: 10px 14px; border: 2px solid #e9ecef; border-radius: 8px; font-size: 0.9rem; transition: all 0.3s ease; font-family: inherit;">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label style="font-size: 0.85rem; display: block; font-weight: 600; color: #1a1f36; margin-bottom: 5px;">Notes</label>
                    <input type="text" name="notes" placeholder="Any notes" style="width: 100%; padding: 10px 14px; border: 2px solid #e9ecef; border-radius: 8px; font-size: 0.9rem; transition: all 0.3s ease; font-family: inherit;">
                </div>
            </div>
            
            <div style="margin-top: 15px; display: flex; flex-wrap: wrap; gap: 10px;">
                <input type="hidden" name="submit_fee" value="1">
                <button type="submit" class="btn-submit" style="flex: 1; min-width: 120px;">💳 Submit Fee</button>
                <button type="reset" class="btn-reset" style="flex: 1; min-width: 120px;">🔄 Reset</button>
            </div>
        </form>
    </div>
    
    <!-- Student Fee Summary -->
    <?php if ($summary_student_id && $student_info): ?>
        <div class="student-info">
            <strong>Student:</strong> <?php echo htmlspecialchars($student_info['first_name'] . ' ' . $student_info['last_name']); ?> | 
            <strong>ID:</strong> <?php echo htmlspecialchars($student_info['student_id']); ?> | 
            <strong>Class:</strong> <?php echo htmlspecialchars($student_info['class']); ?> | 
            <strong>Admission:</strong> <?php echo date('d-M-Y', strtotime($student_info['admission_date'])); ?> | 
            <strong>Monthly Fee:</strong> RS. <?php echo number_format($student_info['fee'], 2); ?>
        </div>
        
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
            <h5 style="margin: 0;">📋 Monthly Fee Records</h5>
            <a href="dashboard.php?page=fee_management<?php echo $selected_class ? '&class_filter='.urlencode($selected_class) : ''; ?><?php echo $search_query ? '&search='.urlencode($search_query) : ''; ?>" class="btn-back">← Back to All Students</a>
        </div>
        
        <div class="fee-table-wrapper">
            <div class="table-responsive">
                <table class="fee-table">
                    <thead>
                        <tr>
                            <th>Month</th>
                            <th>Year</th>
                            <th>Total</th>
                            <th>Paid</th>
                            <th>Pending</th>
                            <th>Due Date</th>
                            <th>Payment Date</th>
                            <th>Status</th>
                            <th>Receipt</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($fee_records)): ?>
                            <?php foreach($fee_records as $record): ?>
                                <tr>
                                    <td><?php echo date('F', mktime(0,0,0,$record['month'],1)); ?></td>
                                    <td><?php echo $record['year']; ?></td>
                                    <td>RS. <?php echo number_format($record['total_amount'], 2); ?></td>
                                    <td>RS. <?php echo number_format($record['paid_amount'], 2); ?></td>
                                    <td>RS. <?php echo number_format($record['remaining_amount'], 2); ?></td>
                                    <td><?php echo date('d-M-Y', strtotime($record['due_date'])); ?></td>
                                    <td><?php echo $record['payment_date'] ? date('d-M-Y', strtotime($record['payment_date'])) : '-'; ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $record['status']; ?>">
                                            <?php echo ucfirst($record['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo $record['receipt_number'] ?: '-'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="9" style="text-align: center; padding: 30px; color: #6c757d;">
                                    No fee records found for this student.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
    <?php else: ?>
        <!-- All Students View -->
        <div class="fee-table-wrapper">
            <div class="table-header">
                <div class="left-section">
                    <h5>👥 All Students Fee Summary</h5>
                    <span class="results-count"><?php echo count($all_students_summary); ?> students</span>
                </div>
                
                <form method="GET" action="dashboard.php" class="search-box" id="searchForm">
                    <input type="hidden" name="page" value="fee_management">
                    <?php if ($selected_class): ?>
                        <input type="hidden" name="class_filter" value="<?php echo htmlspecialchars($selected_class); ?>">
                    <?php endif; ?>
                    <span class="search-icon">🔍</span>
                    <input type="text" 
                           name="search" 
                           id="searchInput" 
                           placeholder="Search by name, ID..." 
                           value="<?php echo htmlspecialchars($search_query); ?>"
                           autocomplete="off">
                    <button type="submit" class="btn-search">Search</button>
                    <?php if ($search_query): ?>
                        <a href="dashboard.php?page=fee_management<?php echo $selected_class ? '&class_filter='.urlencode($selected_class) : ''; ?>" class="btn-clear">✕ Clear</a>
                    <?php endif; ?>
                </form>
            </div>
            
            <div class="table-responsive">
                <table class="fee-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Class</th>
                            <th>Admission Date</th>
                            <th>Monthly Fee</th>
                            <th>Pending Months</th>
                            <th>Total Paid</th>
                            <th>Total Pending</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($all_students_summary)): ?>
                            <?php $count = 1; ?>
                            <?php foreach($all_students_summary as $student): 
                                if ($student['total_pending'] == 0 && $student['total_paid'] > 0) {
                                    $status_class = 'paid';
                                    $status_text = '✅ Paid';
                                } elseif ($student['total_pending'] > 0 && $student['total_paid'] > 0) {
                                    $status_class = 'partial';
                                    $status_text = '⏳ Partial';
                                } elseif ($student['total_pending'] > 0) {
                                    $status_class = 'pending';
                                    $status_text = '⏰ Pending';
                                } else {
                                    $status_class = 'pending';
                                    $status_text = '⏰ Pending';
                                }
                            ?>
                                <tr>
                                    <td><?php echo $count++; ?></td>
                                    <td><strong><?php echo htmlspecialchars($student['student_id']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></td>
                                    <td>Class <?php echo htmlspecialchars($student['class']); ?></td>
                                    <td><?php echo date('d-M-Y', strtotime($student['admission_date'])); ?></td>
                                    <td>RS. <?php echo number_format($student['fee'], 2); ?></td>
                                    <td>
                                        <?php if ($student['pending_months'] > 0): ?>
                                            <span class="pending-badge"><?php echo $student['pending_months']; ?> month<?php echo $student['pending_months'] > 1 ? 's' : ''; ?></span>
                                        <?php else: ?>
                                            <span style="color: #28a745;">✅ All paid</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="color: #28a745; font-weight: 600;">
                                        RS. <?php echo number_format($student['total_paid'], 2); ?>
                                    </td>
                                    <td style="color: #dc3545; font-weight: 600;">
                                        RS. <?php echo number_format($student['total_pending'], 2); ?>
                                    </td>
                                    <td>
                                        <span class="status-badge <?php echo $status_class; ?>">
                                            <?php echo $status_text; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="dashboard.php?page=fee_management&view_student=<?php echo $student['id']; ?><?php echo $selected_class ? '&class_filter='.urlencode($selected_class) : ''; ?><?php echo $search_query ? '&search='.urlencode($search_query) : ''; ?>" class="btn-view">
                                            👁️ View
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="11" style="text-align: center; padding: 30px; color: #6c757d;">
                                    <?php if ($search_query): ?>
                                        No students found matching "<strong><?php echo htmlspecialchars($search_query); ?></strong>"
                                    <?php else: ?>
                                        No students found. Add students first.
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // ===== SEARCH BOX - Auto submit on Enter =====
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('keyup', function(e) {
                if (e.key === 'Enter') {
                    this.form.submit();
                }
            });
        }
        
        // ===== STUDENT SELECT - Show fee info =====
        const studentSelect = document.getElementById('studentSelect');
        const amountPaid = document.getElementById('amountPaid');
        const feeInfo = document.getElementById('feeInfo');
        const monthSelect = document.getElementById('monthSelect');
        const yearSelect = document.getElementById('yearSelect');
        
        if (studentSelect) {
            studentSelect.addEventListener('change', function() {
                const selectedOption = this.options[this.selectedIndex];
                const fee = selectedOption.getAttribute('data-fee');
                const admissionDate = selectedOption.getAttribute('data-admission');
                
                if (fee && fee > 0) {
                    feeInfo.textContent = '💰 Monthly fee: RS. ' + parseFloat(fee).toFixed(2);
                    amountPaid.max = fee;
                    amountPaid.placeholder = 'Enter amount (max RS. ' + parseFloat(fee).toFixed(2) + ')';
                } else {
                    feeInfo.textContent = '';
                    amountPaid.max = '';
                    amountPaid.placeholder = 'Enter amount';
                }
                
                // ===== Disable months before admission and future months =====
                if (admissionDate) {
                    const admission = new Date(admissionDate);
                    const currentDate = new Date();
                    
                    // Enable all months first
                    for (let i = 0; i < monthSelect.options.length; i++) {
                        monthSelect.options[i].disabled = false;
                    }
                    
                    const admMonth = admission.getMonth() + 1;
                    const admYear = admission.getFullYear();
                    const currentMonth = currentDate.getMonth() + 1;
                    const currentYear = currentDate.getFullYear();
                    const selectedYear = parseInt(yearSelect.value);
                    
                    for (let i = 0; i < monthSelect.options.length; i++) {
                        const monthVal = parseInt(monthSelect.options[i].value);
                        if (monthVal) {
                            // Disable if before admission
                            if (selectedYear < admYear || (selectedYear == admYear && monthVal < admMonth)) {
                                monthSelect.options[i].disabled = true;
                            }
                            // Disable if in future
                            if (selectedYear > currentYear || (selectedYear == currentYear && monthVal > currentMonth)) {
                                monthSelect.options[i].disabled = true;
                            }
                        }
                    }
                }
            });
        }
        
        // ===== AMOUNT VALIDATION =====
        if (amountPaid) {
            amountPaid.addEventListener('input', function() {
                const max = parseFloat(this.max);
                const value = parseFloat(this.value);
                
                if (max && value > max) {
                    this.value = max;
                    alert('⚠️ Amount cannot exceed RS. ' + max.toFixed(2));
                }
            });
        }
        
        // ===== YEAR CHANGE - Update month availability =====
        if (yearSelect) {
            yearSelect.addEventListener('change', function() {
                const event = new Event('change');
                studentSelect.dispatchEvent(event);
            });
        }
    });
    </script>
</body>
</html>