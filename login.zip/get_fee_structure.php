<?php
// get_fee_structure.php - Get fee structure for a class
session_start();
if (!isset($_SESSION['logged_in'])) {
    echo json_encode(['fee_amount' => null]);
    exit();
}

include 'db.php';

if (isset($_GET['class'])) {
    $class = mysqli_real_escape_string($conn, $_GET['class']);
    
    // Get current academic year
    $year_query = "SELECT year_name FROM academic_years WHERE is_current = 1 AND status = 'active'";
    $year_result = mysqli_query($conn, $year_query);
    $current_year = mysqli_fetch_assoc($year_result);
    $academic_year = $current_year ? $current_year['year_name'] : '2024-2025';
    
    // Get fee structure
    $fee_query = "SELECT amount FROM fee_structures 
                  WHERE class = '$class' 
                  AND academic_year = '$academic_year' 
                  AND status = 'active' 
                  LIMIT 1";
    $fee_result = mysqli_query($conn, $fee_query);
    
    if ($fee_data = mysqli_fetch_assoc($fee_result)) {
        echo json_encode(['fee_amount' => (float)$fee_data['amount']]);
    } else {
        echo json_encode(['fee_amount' => null]);
    }
} else {
    echo json_encode(['fee_amount' => null]);
}

mysqli_close($conn);
?>