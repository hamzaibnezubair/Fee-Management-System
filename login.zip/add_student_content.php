<?php
// add_student_content.php - This file contains the complete add student form
// It will be included in dashboard.php when page=add_student


if (!isset($_SESSION['logged_in'])) {
    header("Location: login.php");
    exit();
}

// Include database connection
include 'db.php';

$success = '';
$error = '';
$email_error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Generate unique student ID
    $student_id = 'STU' . date('Y') . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
    
    // Sanitize inputs
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $father_name = mysqli_real_escape_string($conn, $_POST['father_name']);
    $mother_name = mysqli_real_escape_string($conn, $_POST['mother_name']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $class = mysqli_real_escape_string($conn, $_POST['class']);
    $section = mysqli_real_escape_string($conn, $_POST['section']);
    $fee = mysqli_real_escape_string($conn, $_POST['fee']);
    $contact_number = mysqli_real_escape_string($conn, $_POST['contact_number']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $state = mysqli_real_escape_string($conn, $_POST['state']);
    $pin_code = mysqli_real_escape_string($conn, $_POST['pin_code']);
    
    // ===== FIX: Use the admission date from the form =====
    $admission_date = mysqli_real_escape_string($conn, $_POST['admission_date']);
    
    // Check if email already exists
    $check_sql = "SELECT id FROM students WHERE email = '$email'";
    $check_result = mysqli_query($conn, $check_sql);
    
    if (mysqli_num_rows($check_result) > 0) {
        $email_error = "This email is already registered in the system!";
    } else {
        // Insert query
        $sql = "INSERT INTO students (
            student_id, first_name, last_name, father_name, mother_name, 
            gender, class, section, fee, contact_number, email, 
            address, city, state, pin_code, admission_date
        ) VALUES (
            '$student_id', '$first_name', '$last_name', '$father_name', '$mother_name',
            '$gender', '$class', '$section', '$fee', '$contact_number', '$email',
            '$address', '$city', '$state', '$pin_code', '$admission_date'
        )";
        
        if (mysqli_query($conn, $sql)) {
            $success = "Student added successfully! Student ID: " . $student_id;
        } else {
            $error = "Error: " . mysqli_error($conn);
        }
    }
}
?>

<!-- ===== ADD STUDENT FORM ===== -->
<div class="header">
    <div>
        <h2>Add New Student</h2>
        <div class="breadcrumb">Student Management / Add Student</div>
    </div>
    <div>
        <a href="dashboard.php?page=view_students" style="background: #28a745; color: white; padding: 8px 18px; border-radius: 6px; text-decoration: none; font-weight: 600; font-size: 0.9rem;">
            👥 View All Students
        </a>
    </div>
</div>

<?php if (isset($success) && $success): ?>
    <div class="alert alert-success">
        ✅ <?php echo $success; ?>
    </div>
<?php endif; ?>

<?php if (isset($error) && $error): ?>
    <div class="alert alert-danger">
        ❌ <?php echo $error; ?>
    </div>
<?php endif; ?>

<form method="POST" action="dashboard.php?page=add_student" id="studentForm">
    <!-- Personal Information -->
    <h4 style="color: #5469d4; margin-bottom: 20px; border-bottom: 2px solid #e9ecef; padding-bottom: 10px;">
        📋 Personal Information
    </h4>
    
    <div class="form-row">
        <div class="form-group">
            <label>First Name <span class="required">*</span></label>
            <input type="text" name="first_name" placeholder="Enter first name" required>
        </div>
        <div class="form-group">
            <label>Last Name <span class="required">*</span></label>
            <input type="text" name="last_name" placeholder="Enter last name" required>
        </div>
    </div>
    
    <div class="form-row">
        <div class="form-group">
            <label>Father's Name <span class="required">*</span></label>
            <input type="text" name="father_name" placeholder="Enter father's name" required>
        </div>
        <div class="form-group">
            <label>Mother's Name</label>
            <input type="text" name="mother_name" placeholder="Enter mother's name">
        </div>
    </div>
    
    <div class="form-row-3">
        <div class="form-group">
            <label>Gender <span class="required">*</span></label>
            <select name="gender" required>
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
            </select>
        </div>
        <div class="form-group">
            <label>Class <span class="required">*</span></label>
            <select name="class" required>
                <option value="">Select Class</option>
                <option value="Play Group">Play Group</option>
                <option value="Nursery">Nursery</option>
                <option value="Prep">Prep</option>
                <option value="1">Class 1</option>
                <option value="2">Class 2</option>
                <option value="3">Class 3</option>
                <option value="4">Class 4</option>
                <option value="5">Class 5</option>
                <option value="6">Class 6</option>
                <option value="7">Class 7</option>
                <option value="8">Class 8</option>
                <option value="9">Class 9</option>
                <option value="10">Class 10</option>
            </select>
        </div>
        <div class="form-group">
            <label>Section</label>
            <input type="text" name="section" placeholder="A, B, C...">
        </div>
    </div>
    
    <!-- Contact & Fee Information -->
    <h4 style="color: #5469d4; margin: 30px 0 20px; border-bottom: 2px solid #e9ecef; padding-bottom: 10px;">
        📞 Contact & Fee Information
    </h4>
    
    <div class="form-row">
        <div class="form-group">
            <label>Contact Number <span class="required">*</span></label>
            <input type="tel" name="contact_number" placeholder="+92 300 1234567" required>
        </div>
        <div class="form-group">
            <label>Email Address <span class="required">*</span></label>
            <input type="email" name="email" id="email" placeholder="student@example.com" required>
            <span class="email-validation-icon" id="emailValidationIcon"></span>
            <div class="email-error-message" id="emailErrorMessage">
                ⚠️ This email is already registered in the system!
            </div>
            <div class="email-success-message" id="emailSuccessMessage">
                ✅ Email is available
            </div>
        </div>
    </div>
    
    <div class="form-row">
        <div class="form-group">
            <label>Monthly Fee <span class="required">*</span></label>
            <input type="number" name="fee" placeholder="5000" step="0.01" required>
        </div>
        <div class="form-group">
            <label>Admission Date <span class="required">*</span></label>
            <input type="date" name="admission_date" id="admission_date" value="<?php echo date('Y-m-d'); ?>" required>
        </div>
    </div>
    
    <!-- Address Information -->
    <h4 style="color: #5469d4; margin: 30px 0 20px; border-bottom: 2px solid #e9ecef; padding-bottom: 10px;">
        🏠 Address Information
    </h4>
    
    <div class="form-group">
        <label>Address <span class="required">*</span></label>
        <textarea name="address" placeholder="Enter complete address" required></textarea>
    </div>
    
    <div class="form-row-3">
        <div class="form-group">
            <label>City</label>
            <input type="text" name="city" placeholder="City">
        </div>
        <div class="form-group">
            <label>State</label>
            <input type="text" name="state" placeholder="State">
        </div>
        <div class="form-group">
            <label>Pin Code</label>
            <input type="text" name="pin_code" placeholder="Pin Code">
        </div>
    </div>
    
    <!-- Form Actions -->
    <div style="margin-top: 30px; padding-top: 20px; border-top: 2px solid #f0f2f5; display: flex; gap: 10px; flex-wrap: wrap;">
        <button type="submit" class="btn-submit" id="submitBtn">
            ✅ Add Student
        </button>
        <button type="reset" class="btn-reset">
            🔄 Reset
        </button>
        <a href="dashboard.php?page=view_students" style="background: #17a2b8; color: white; padding: 12px 35px; border: none; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer; transition: all 0.3s ease; text-decoration: none; display: inline-flex; align-items: center;">
            👥 View Students
        </a>
    </div>
</form>

<!-- ===== EMAIL VALIDATION SCRIPT ===== -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const emailInput = document.getElementById('email');
    const submitBtn = document.getElementById('submitBtn');
    const validationIcon = document.getElementById('emailValidationIcon');
    const errorMessage = document.getElementById('emailErrorMessage');
    const successMessage = document.getElementById('emailSuccessMessage');
    let typingTimer;
    const doneTypingInterval = 500;
    
    if (emailInput) {
        emailInput.addEventListener('input', function() {
            clearTimeout(typingTimer);
            
            const email = this.value.trim();
            
            // Clear previous states
            this.classList.remove('error', 'success');
            validationIcon.className = 'email-validation-icon';
            errorMessage.classList.remove('show');
            successMessage.classList.remove('show');
            submitBtn.disabled = false;
            
            if (email === '') {
                validationIcon.textContent = '';
                return;
            }
            
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                validationIcon.textContent = '❌';
                validationIcon.className = 'email-validation-icon invalid';
                submitBtn.disabled = true;
                errorMessage.textContent = '⚠️ Please enter a valid email address';
                errorMessage.classList.add('show');
                return;
            }
            
            validationIcon.textContent = '⏳';
            validationIcon.className = 'email-validation-icon loading';
            
            typingTimer = setTimeout(function() {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'check_email.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            
                            if (response.exists) {
                                emailInput.classList.add('error');
                                emailInput.classList.remove('success');
                                validationIcon.textContent = '❌';
                                validationIcon.className = 'email-validation-icon invalid';
                                errorMessage.textContent = '⚠️ ' + response.message;
                                errorMessage.classList.add('show');
                                successMessage.classList.remove('show');
                                submitBtn.disabled = true;
                            } else {
                                emailInput.classList.add('success');
                                emailInput.classList.remove('error');
                                validationIcon.textContent = '✅';
                                validationIcon.className = 'email-validation-icon valid';
                                errorMessage.classList.remove('show');
                                successMessage.textContent = '✅ ' + response.message;
                                successMessage.classList.add('show');
                                submitBtn.disabled = false;
                            }
                        } catch(e) {
                            console.error('Error parsing response:', e);
                        }
                    }
                };
                
                xhr.send('email=' + encodeURIComponent(email));
            }, doneTypingInterval);
        });
    }
});
</script>