<?php

if (!isset($_SESSION['logged_in'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

// Handle Delete
if (isset($_GET['delete']) && isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $delete_sql = "DELETE FROM students WHERE id = '$id'";
    if (mysqli_query($conn, $delete_sql)) {
        $delete_success = "Student deleted successfully!";
    } else {
        $delete_error = "Error deleting student: " . mysqli_error($conn);
    }
}

// Handle Edit - Get student data
$edit_student = null;
if (isset($_GET['edit']) && isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $edit_sql = "SELECT * FROM students WHERE id = '$id'";
    $edit_result = mysqli_query($conn, $edit_sql);
    if (mysqli_num_rows($edit_result) > 0) {
        $edit_student = mysqli_fetch_assoc($edit_result);
    }
}

// Handle Update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_student'])) {
    $id = mysqli_real_escape_string($conn, $_POST['student_id']);
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $father_name = mysqli_real_escape_string($conn, $_POST['father_name']);
    $mother_name = mysqli_real_escape_string($conn, $_POST['mother_name']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $class = mysqli_real_escape_string($conn, $_POST['class']);
    $section = mysqli_real_escape_string($conn, $_POST['section']);
    $fee = mysqli_real_escape_string($conn, $_POST['fee']);
    $contact_number = mysqli_real_escape_string($conn, $_POST['contact_number']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $state = mysqli_real_escape_string($conn, $_POST['state']);
    $pin_code = mysqli_real_escape_string($conn, $_POST['pin_code']);
    
    $update_sql = "UPDATE students SET 
        first_name = '$first_name',
        last_name = '$last_name',
        father_name = '$father_name',
        mother_name = '$mother_name',
        gender = '$gender',
        class = '$class',
        section = '$section',
        fee = '$fee',
        contact_number = '$contact_number',
        email = '$email',
        address = '$address',
        city = '$city',
        state = '$state',
        pin_code = '$pin_code'
        WHERE id = '$id'";
    
    if (mysqli_query($conn, $update_sql)) {
        $update_success = "Student updated successfully!";
        $edit_student = null; // Clear edit mode
        // Refresh data
        $id = mysqli_real_escape_string($conn, $_POST['student_id']);
        $edit_sql = "SELECT * FROM students WHERE id = '$id'";
        $edit_result = mysqli_query($conn, $edit_sql);
        if (mysqli_num_rows($edit_result) > 0) {
            $edit_student = mysqli_fetch_assoc($edit_result);
        }
    } else {
        $update_error = "Error updating student: " . mysqli_error($conn);
    }
}

// Search and Filter
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$class_filter = isset($_GET['class_filter']) ? mysqli_real_escape_string($conn, $_GET['class_filter']) : '';

// Build query
$sql = "SELECT * FROM students WHERE 1=1";
if ($search) {
    $sql .= " AND (first_name LIKE '%$search%' OR last_name LIKE '%$search%' OR father_name LIKE '%$search%' OR email LIKE '%$search%' OR student_id LIKE '%$search%')";
}
if ($class_filter) {
    $sql .= " AND class = '$class_filter'";
}
$sql .= " ORDER BY created_at DESC";

$result = mysqli_query($conn, $sql);
$total_students = mysqli_num_rows($result);
?>
<!DOCTYPE html>
<html>
<head>
    <style>
        .students-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .students-header h4 {
            margin: 0;
            font-weight: 600;
            color: #1a1f36;
        }
        
        .students-header .badge-count {
            background: #5469d4;
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
        }
        
        .search-filter {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }
        
        .search-filter input,
        .search-filter select {
            padding: 10px 14px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }
        
        .search-filter input:focus,
        .search-filter select:focus {
            outline: none;
            border-color: #5469d4;
            box-shadow: 0 0 0 3px rgba(84,105,212,0.1);
        }
        
        .search-filter input {
            flex: 1;
            min-width: 200px;
        }
        
        .search-filter select {
            min-width: 150px;
        }
        
        .search-filter .btn-search {
            background: #5469d4;
            color: white;
            padding: 10px 25px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .search-filter .btn-search:hover {
            background: #3f55b8;
        }
        
        .search-filter .btn-reset {
            background: #6c757d;
            color: white;
            padding: 10px 25px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        
        .search-filter .btn-reset:hover {
            background: #5a6268;
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }
        
        .table th {
            background: #f8f9fa;
            color: #1a1f36;
            font-weight: 600;
            padding: 12px 15px;
            text-align: left;
            border-bottom: 2px solid #e9ecef;
            white-space: nowrap;
        }
        
        .table td {
            padding: 12px 15px;
            border-bottom: 1px solid #e9ecef;
            vertical-align: middle;
        }
        
        .table tr:hover {
            background: #f8f9fa;
        }
        
        .table .actions {
            display: flex;
            gap: 8px;
        }
        
        .table .actions .btn-icon {
            padding: 6px 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.85rem;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        
        .table .actions .btn-edit {
            background: #ffc107;
            color: #1a1f36;
        }
        
        .table .actions .btn-edit:hover {
            background: #e0a800;
        }
        
        .table .actions .btn-delete {
            background: #dc3545;
            color: white;
        }
        
        .table .actions .btn-delete:hover {
            background: #c82333;
        }
        
        .table .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .status-badge.active {
            background: #d4edda;
            color: #155724;
        }
        
        .status-badge.inactive {
            background: #f8d7da;
            color: #721c24;
        }
        
        .status-badge.graduated {
            background: #fff3cd;
            color: #856404;
        }
        
        .no-data {
            text-align: center;
            padding: 40px 20px;
            color: #6c757d;
        }
        
        .no-data .icon {
            font-size: 3rem;
            margin-bottom: 15px;
            opacity: 0.3;
        }
        
        /* ===== EDIT PANEL STYLES ===== */
        .edit-panel {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 30px;
            border: 2px solid #5469d4;
            position: relative;
        }
        
        .edit-panel .panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .edit-panel .panel-header h5 {
            margin: 0;
            color: #1a1f36;
            font-weight: 600;
        }
        
        .edit-panel .panel-header .btn-close-panel {
            background: #dc3545;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
        }
        
        .edit-panel .panel-header .btn-close-panel:hover {
            background: #c82333;
        }
        
        .edit-panel .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        .edit-panel .form-row-3 {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 15px;
        }
        
        .edit-panel .form-group {
            margin-bottom: 15px;
        }
        
        .edit-panel .form-group label {
            display: block;
            font-weight: 600;
            font-size: 0.85rem;
            color: #1a1f36;
            margin-bottom: 4px;
        }
        
        .edit-panel .form-group input,
        .edit-panel .form-group select,
        .edit-panel .form-group textarea {
            width: 100%;
            padding: 8px 12px;
            border: 2px solid #e9ecef;
            border-radius: 6px;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            font-family: inherit;
        }
        
        .edit-panel .form-group input:focus,
        .edit-panel .form-group select:focus,
        .edit-panel .form-group textarea:focus {
            outline: none;
            border-color: #5469d4;
            box-shadow: 0 0 0 3px rgba(84,105,212,0.1);
        }
        
        .edit-panel .form-group textarea {
            resize: vertical;
            min-height: 60px;
        }
        
        .edit-panel .btn-update {
            background: #28a745;
            color: white;
            padding: 12px 35px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .edit-panel .btn-update:hover {
            background: #218838;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(40,167,69,0.3);
        }
        
        .edit-panel .btn-cancel {
            background: #6c757d;
            color: white;
            padding: 12px 35px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-left: 10px;
        }
        
        .edit-panel .btn-cancel:hover {
            background: #5a6268;
        }
        
        .alert {
            padding: 12px 18px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-weight: 500;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        @media (max-width: 768px) {
            .students-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .search-filter {
                flex-direction: column;
            }
            
            .search-filter input,
            .search-filter select {
                width: 100%;
            }
            
            .edit-panel .form-row,
            .edit-panel .form-row-3 {
                grid-template-columns: 1fr;
            }
            
            .table {
                font-size: 0.8rem;
            }
            
            .table th,
            .table td {
                padding: 8px 10px;
            }
        }
    </style>
</head>
<body>
    <?php if (isset($delete_success)): ?>
        <div class="alert alert-success">✅ <?php echo $delete_success; ?></div>
    <?php endif; ?>
    
    <?php if (isset($delete_error)): ?>
        <div class="alert alert-danger">❌ <?php echo $delete_error; ?></div>
    <?php endif; ?>
    
    <?php if (isset($update_success)): ?>
        <div class="alert alert-success">✅ <?php echo $update_success; ?></div>
    <?php endif; ?>
    
    <?php if (isset($update_error)): ?>
        <div class="alert alert-danger">❌ <?php echo $update_error; ?></div>
    <?php endif; ?>
    
    <?php if ($edit_student): ?>
        <!-- ===== EDIT PANEL ===== -->
        <div class="edit-panel">
            <div class="panel-header">
                <h5>✏️ Edit Student: <?php echo htmlspecialchars($edit_student['first_name'] . ' ' . $edit_student['last_name']); ?></h5>
                <a href="dashboard.php?page=view_students" class="btn-close-panel">✕ Close</a>
            </div>
            
            <form method="POST" action="dashboard.php?page=view_students">
                <input type="hidden" name="student_id" value="<?php echo $edit_student['id']; ?>">
                <input type="hidden" name="update_student" value="1">
                
                <div class="form-row">
                    <div class="form-group">
                        <label>First Name <span style="color: #dc3545;">*</span></label>
                        <input type="text" name="first_name" value="<?php echo htmlspecialchars($edit_student['first_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Last Name <span style="color: #dc3545;">*</span></label>
                        <input type="text" name="last_name" value="<?php echo htmlspecialchars($edit_student['last_name']); ?>" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Father's Name <span style="color: #dc3545;">*</span></label>
                        <input type="text" name="father_name" value="<?php echo htmlspecialchars($edit_student['father_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Mother's Name</label>
                        <input type="text" name="mother_name" value="<?php echo htmlspecialchars($edit_student['mother_name']); ?>">
                    </div>
                </div>
                
                <div class="form-row-3">
                    <div class="form-group">
                        <label>Gender <span style="color: #dc3545;">*</span></label>
                        <select name="gender" required>
                            <option value="Male" <?php echo $edit_student['gender'] == 'Male' ? 'selected' : ''; ?>>Male</option>
                            <option value="Female" <?php echo $edit_student['gender'] == 'Female' ? 'selected' : ''; ?>>Female</option>
                            <option value="Other" <?php echo $edit_student['gender'] == 'Other' ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Class <span style="color: #dc3545;">*</span></label>
                       <select name="class" required>
    <option value="">Select Class</option>
    <option value="Play Group" <?php echo isset($edit_student) && $edit_student['class'] == 'Play Group' ? 'selected' : ''; ?>>Play Group</option>
    <option value="Nursery" <?php echo isset($edit_student) && $edit_student['class'] == 'Nursery' ? 'selected' : ''; ?>>Nursery</option>
    <option value="Prep" <?php echo isset($edit_student) && $edit_student['class'] == 'Prep' ? 'selected' : ''; ?>>Prep</option>
    <?php for($i=1; $i<=10; $i++): ?>
        <option value="<?php echo $i; ?>" <?php echo isset($edit_student) && $edit_student['class'] == $i ? 'selected' : ''; ?>>Class <?php echo $i; ?></option>
    <?php endfor; ?>
</select>
                    </div>
                    <div class="form-group">
                        <label>Section</label>
                        <input type="text" name="section" value="<?php echo htmlspecialchars($edit_student['section']); ?>">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Contact Number <span style="color: #dc3545;">*</span></label>
                        <input type="text" name="contact_number" value="<?php echo htmlspecialchars($edit_student['contact_number']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Email <span style="color: #dc3545;">*</span></label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($edit_student['email']); ?>" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Monthly Fee <span style="color: #dc3545;">*</span></label>
                        <input type="number" name="fee" value="<?php echo htmlspecialchars($edit_student['fee']); ?>" step="0.01" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Address <span style="color: #dc3545;">*</span></label>
                    <textarea name="address" required><?php echo htmlspecialchars($edit_student['address']); ?></textarea>
                </div>
                
                <div class="form-row-3">
                    <div class="form-group">
                        <label>City</label>
                        <input type="text" name="city" value="<?php echo htmlspecialchars($edit_student['city']); ?>">
                    </div>
                    <div class="form-group">
                        <label>State</label>
                        <input type="text" name="state" value="<?php echo htmlspecialchars($edit_student['state']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Pin Code</label>
                        <input type="text" name="pin_code" value="<?php echo htmlspecialchars($edit_student['pin_code']); ?>">
                    </div>
                </div>
                
                <div style="margin-top: 20px;">
                    <button type="submit" class="btn-update">💾 Update Student</button>
                    <a href="dashboard.php?page=view_students" class="btn-cancel">Cancel</a>
                </div>
            </form>
        </div>
    <?php endif; ?>
    
    <!-- ===== VIEW STUDENTS TABLE ===== -->
    <div class="students-header">
        <div>
          
            <span class="badge-count">Total: <?php echo $total_students; ?> students</span>
        </div>
        <a href="dashboard.php?page=add_student" style="background: #28a745; color: white; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-weight: 600;">
            ➕ Add New Student
        </a>
    </div>
    
    <!-- Search & Filter -->
    <form method="GET" action="dashboard.php" class="search-filter">
        <input type="hidden" name="page" value="view_students">
        <input type="text" name="search" placeholder="🔍 Search by name, father, email..." value="<?php echo htmlspecialchars($search); ?>">
        <select name="class_filter">
    <option value="">All Classes</option>
    <option value="Play Group" <?php echo $class_filter == 'Play Group' ? 'selected' : ''; ?>>Play Group</option>
    <option value="Nursery" <?php echo $class_filter == 'Nursery' ? 'selected' : ''; ?>>Nursery</option>
    <option value="Prep" <?php echo $class_filter == 'Prep' ? 'selected' : ''; ?>>Prep</option>
    <?php for($i=1; $i<=10; $i++): ?>
        <option value="<?php echo $i; ?>" <?php echo $class_filter == $i ? 'selected' : ''; ?>>Class <?php echo $i; ?></option>
    <?php endfor; ?>
</select>
        <button type="submit" class="btn-search">🔍 Search</button>
        <a href="dashboard.php?page=view_students" class="btn-reset">↻ Reset</a>
    </form>
    
    <!-- Students Table -->
    <?php if (mysqli_num_rows($result) > 0): ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Student ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Father Name</th>
                        <th>Class</th>
                        <th>Section</th>
                        <th>Fee</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $count = 1; ?>
                    <?php while($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo $count++; ?></td>
                            <td><strong><?php echo htmlspecialchars($row['student_id']); ?></strong></td>
                            <td><?php echo htmlspecialchars($row['first_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['father_name']); ?></td>
                            <td>Class <?php echo htmlspecialchars($row['class']); ?></td>
                            <td><?php echo htmlspecialchars($row['section']); ?></td>
                            <td><strong>RS. <?php echo number_format($row['fee'], 0); ?></strong></td>
                            <td>
                                <span class="status-badge <?php echo $row['status']; ?>">
                                    <?php echo ucfirst($row['status']); ?>
                                </span>
                            </td>
                            <td>
                                <div class="actions">
                                    <a href="dashboard.php?page=view_students&edit=1&id=<?php echo $row['id']; ?>" class="btn-icon btn-edit">
                                        ✏️ Edit
                                    </a>
                                    <a href="#" onclick="confirmDelete(<?php echo $row['id']; ?>); return false;" class="btn-icon btn-delete">
                                        🗑️ Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="no-data">
            <div class="icon">📭</div>
            <h5>No Students Found</h5>
            <p>Try adjusting your search filters or add a new student.</p>
            <a href="dashboard.php?page=add_student" style="background: #5469d4; color: white; padding: 10px 25px; border-radius: 8px; text-decoration: none; display: inline-block; margin-top: 10px;">
                ➕ Add Student
            </a>
        </div>
    <?php endif; ?>
    
    <!-- ===== DELETE CONFIRMATION SCRIPT ===== -->
    <script>
        function confirmDelete(id) {
            if (confirm('Are you sure you want to delete this student? This action cannot be undone!')) {
                window.location.href = 'dashboard.php?page=view_students&delete=1&id=' + id;
            }
        }
    </script>
</body>
</html>