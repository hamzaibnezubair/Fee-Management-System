<?php
// check_email.php - AJAX endpoint to check if email exists
session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in'])) {
    echo json_encode(['exists' => false, 'message' => 'Unauthorized']);
    exit();
}

// Include database connection
include 'db.php';

// Get email from POST request
if (isset($_POST['email'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    
    // Check if email exists in students table
    $sql = "SELECT id FROM students WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        echo json_encode([
            'exists' => true,
            'message' => 'This email is already registered in the system!'
        ]);
    } else {
        echo json_encode([
            'exists' => false,
            'message' => 'Email is available'
        ]);
    }
} else {
    echo json_encode([
        'exists' => false,
        'message' => 'No email provided'
    ]);
}

mysqli_close($conn);
?>