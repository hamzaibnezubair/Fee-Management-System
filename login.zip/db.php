<?php
// db.php - Database connection file

// Database configuration
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'fee';

// Create connection
$conn = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Set character set
mysqli_set_charset($conn, "utf8");

// Note: Don't close connection here, it will be closed in the page that includes this file
?>