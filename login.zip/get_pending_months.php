<?php
// get_pending_months.php - Get pending months for a student
session_start();
if (!isset($_SESSION['logged_in'])) {
    echo json_encode(['pending_months' => 0]);
    exit();
}

include 'db.php';

if (isset($_GET['student_id']) && isset($_GET['admission_date'])) {
    $student_id = mysqli_real_escape_string($conn, $_GET['student_id']);
    $admission_date = mysqli_real_escape_string($conn, $_GET['admission_date']);
    
    // Get current academic year
    $year_query = "SELECT year_name FROM academic_years WHERE is_current = 1 AND status = 'active'";
    $year_result = mysqli_query($conn, $year_query);
    $current_year = mysqli_fetch_assoc($year_result);
    $academic_year = $current_year ? $current_year['year_name'] : '2024-2025';
    
    // Count pending months
    $pending_query = "SELECT COUNT(*) as pending_count FROM student_fees 
                      WHERE student_id = '$student_id' 
                      AND academic_year = '$academic_year'
                      AND status IN ('pending', 'overdue')";
    $pending_result = mysqli_query($conn, $pending_query);
    $pending_data = mysqli_fetch_assoc($pending_result);
    
    echo json_encode(['pending_months' => (int)$pending_data['pending_count']]);
} else {
    echo json_encode(['pending_months' => 0]);
}

mysqli_close($conn);
?>