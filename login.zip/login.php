<?php
// Start session to store user data
session_start();

include'db.php';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get and sanitize input
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    
    // Query to check user credentials
    $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) == 1) {
        // Login successful
        $user = mysqli_fetch_assoc($result);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['logged_in'] = true;
        
        // Redirect to dashboard
        header("Location: dashboard.php");
        exit();
    } else {
        // Login failed
        $error_message = "Invalid email or password!";
    }
}

// Close connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Fee Management System – Sign in</title>
  <style>
    /* ---- reset & base ---- */
    * {
      padding: 0;
      margin: 0;
      color: #1a1f36;
      box-sizing: border-box;
      word-wrap: break-word;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Ubuntu, sans-serif;
    }
    body {
      min-height: 100%;
      background-color: #ffffff;
    }
    h1 {
      letter-spacing: -1px;
    }
    a {
      color: #5469d4;
      text-decoration: unset;
    }

    /* ---- layout & login root ---- */
    .login-root {
      background: #fff;
      display: flex;
      width: 100%;
      min-height: 100vh;
      overflow: hidden;
      position: relative;
    }
    .loginbackground {
      min-height: 692px;
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      top: 0;
      z-index: 0;
      overflow: hidden;
    }
    .flex-flex {
      display: flex;
    }
    .align-center {
      align-items: center;
    }
    .center-center {
      align-items: center;
      justify-content: center;
    }
    .box-root {
      box-sizing: border-box;
    }
    .flex-direction--column {
      flex-direction: column;
    }
    .flex-justifyContent--center {
      justify-content: center;
    }

    /* ---- grid background decorations ---- */
    .loginbackground-gridContainer {
      display: grid;
      grid-template-columns: [start] 1fr [left-gutter] repeat(16, 86.6px) [left-gutter] 1fr [end];
      grid-template-rows: [top] 1fr [top-gutter] repeat(8, 64px) [bottom-gutter] 1fr [bottom];
      justify-content: center;
      margin: 0 -2%;
      transform: rotate(-12deg) skew(-12deg);
    }
    .box-divider--light-all-2 {
      box-shadow: inset 0 0 0 2px #e3e8ee;
    }
    .box-background--blue {
      background-color: #5469d4;
    }
    .box-background--white {
      background-color: #ffffff;
    }
    .box-background--blue800 {
      background-color: #212d63;
    }
    .box-background--gray100 {
      background-color: #e3e8ee;
    }
    .box-background--cyan200 {
      background-color: #7fd3ed;
    }

    /* ---- spacing helpers ---- */
    .padding-top--64 { padding-top: 64px; }
    .padding-top--24 { padding-top: 24px; }
    .padding-top--48 { padding-top: 48px; }
    .padding-bottom--24 { padding-bottom: 24px; }
    .padding-horizontal--48 { padding: 48px; }
    .padding-bottom--15 { padding-bottom: 15px; }

    /* ---- form card ---- */
    .formbg-outer {
      position: relative;
      z-index: 9;
      width: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    .formbg {
      margin: 0 auto;
      width: 100%;
      max-width: 448px;
      background: white;
      border-radius: 4px;
      box-shadow: rgba(60, 66, 87, 0.12) 0px 7px 14px 0px, rgba(0, 0, 0, 0.12) 0px 3px 6px 0px;
    }
    .formbg-inner {
      padding: 48px;
    }
    span {
      display: block;
      font-size: 20px;
      line-height: 28px;
      color: #1a1f36;
    }
    label {
      margin-bottom: 10px;
      font-size: 14px;
      font-weight: 600;
      display: block;
    }
    .reset-pass a {
      font-size: 14px;
      font-weight: 600;
      display: block;
      text-align: right;
      margin-bottom: 10px;
    }
    .grid--50-50 {
      display: grid;
      grid-template-columns: 50% 50%;
      align-items: center;
    }

    /* ---- form fields ---- */
    .field {
      margin-bottom: 0;
    }
    .field input {
      font-size: 16px;
      line-height: 28px;
      padding: 8px 16px;
      width: 100%;
      min-height: 44px;
      border: unset;
      border-radius: 4px;
      outline-color: rgb(84 105 212 / 0.5);
      background-color: rgb(255, 255, 255);
      box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px,
                  rgba(0, 0, 0, 0) 0px 0px 0px 0px,
                  rgba(0, 0, 0, 0) 0px 0px 0px 0px,
                  rgba(60, 66, 87, 0.16) 0px 0px 0px 1px,
                  rgba(0, 0, 0, 0) 0px 0px 0px 0px,
                  rgba(0, 0, 0, 0) 0px 0px 0px 0px,
                  rgba(0, 0, 0, 0) 0px 0px 0px 0px;
    }
    input[type="submit"] {
      background-color: rgb(84, 105, 212);
      box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px,
                  rgba(0, 0, 0, 0) 0px 0px 0px 0px,
                  rgba(0, 0, 0, 0.12) 0px 1px 1px 0px,
                  rgb(84, 105, 212) 0px 0px 0px 1px,
                  rgba(0, 0, 0, 0) 0px 0px 0px 0px,
                  rgba(0, 0, 0, 0) 0px 0px 0px 0px,
                  rgba(60, 66, 87, 0.08) 0px 2px 5px 0px;
      color: #fff;
      font-weight: 600;
      cursor: pointer;
      border: none;
      border-radius: 4px;
    }
    .field-checkbox input {
      width: 20px;
      height: 15px;
      margin-right: 5px;
      box-shadow: unset;
      min-height: unset;
    }
    .field-checkbox label {
      display: flex;
      align-items: center;
      margin: 0;
      font-weight: 400;
      font-size: 14px;
    }
    a.ssolink {
      display: block;
      text-align: center;
      font-weight: 600;
      margin-top: 4px;
    }
    .footer-link span {
      font-size: 14px;
      text-align: center;
    }
    .listing a {
      color: #697386;
      font-weight: 600;
      margin: 0 10px;
    }
    .listing {
      display: flex;
      justify-content: center;
      gap: 0.5rem;
      flex-wrap: wrap;
    }

    /* ---- error message ---- */
    .error-message {
      background-color: #f8d7da;
      color: #721c24;
      padding: 12px 20px;
      border-radius: 4px;
      margin-bottom: 20px;
      border: 1px solid #f5c6cb;
      font-size: 14px;
      display: <?php echo isset($error_message) ? 'block' : 'none'; ?>;
    }

    /* ---- animations ---- */
    .animationRightLeft {
      animation: animationRightLeft 2s ease-in-out infinite;
    }
    .animationLeftRight {
      animation: animationLeftRight 2s ease-in-out infinite;
    }
    .tans3s {
      animation: animationLeftRight 3s ease-in-out infinite;
    }
    .tans4s {
      animation: animationLeftRight 4s ease-in-out infinite;
    }

    @keyframes animationLeftRight {
      0% { transform: translateX(0px); }
      50% { transform: translateX(1000px); }
      100% { transform: translateX(0px); }
    }
    @keyframes animationRightLeft {
      0% { transform: translateX(0px); }
      50% { transform: translateX(-1000px); }
      100% { transform: translateX(0px); }
    }

    /* ---- small tweaks for responsiveness ---- */
    @media (max-width: 600px) {
      .padding-horizontal--48 {
        padding: 24px;
      }
      .formbg-inner {
        padding: 24px;
      }
      .loginbackground-gridContainer {
        margin: 0 -5%;
      }
    }
  </style>
</head>
<body>
<div class="login-root">
  <!-- background decoration (fixed) -->
  <div class="loginbackground box-background--white padding-top--64">
    <div class="loginbackground-gridContainer">
      <div class="box-root flex-flex" style="grid-area: top / start / 8 / end;">
        <div class="box-root" style="background-image: linear-gradient(white 0%, rgb(247, 250, 252) 33%); flex-grow: 1;"></div>
      </div>
      <div class="box-root flex-flex" style="grid-area: 4 / 2 / auto / 5;">
        <div class="box-root box-divider--light-all-2 animationLeftRight tans3s" style="flex-grow: 1;"></div>
      </div>
      <div class="box-root flex-flex" style="grid-area: 6 / start / auto / 2;">
        <div class="box-root box-background--blue800" style="flex-grow: 1;"></div>
      </div>
      <div class="box-root flex-flex" style="grid-area: 7 / start / auto / 4;">
        <div class="box-root box-background--blue animationLeftRight" style="flex-grow: 1;"></div>
      </div>
      <div class="box-root flex-flex" style="grid-area: 8 / 4 / auto / 6;">
        <div class="box-root box-background--gray100 animationLeftRight tans3s" style="flex-grow: 1;"></div>
      </div>
      <div class="box-root flex-flex" style="grid-area: 2 / 15 / auto / end;">
        <div class="box-root box-background--cyan200 animationRightLeft tans4s" style="flex-grow: 1;"></div>
      </div>
      <div class="box-root flex-flex" style="grid-area: 3 / 14 / auto / end;">
        <div class="box-root box-background--blue animationRightLeft" style="flex-grow: 1;"></div>
      </div>
      <div class="box-root flex-flex" style="grid-area: 4 / 17 / auto / 20;">
        <div class="box-root box-background--gray100 animationRightLeft tans4s" style="flex-grow: 1;"></div>
      </div>
      <div class="box-root flex-flex" style="grid-area: 5 / 14 / auto / 17;">
        <div class="box-root box-divider--light-all-2 animationRightLeft tans3s" style="flex-grow: 1;"></div>
      </div>
    </div>
  </div>

  <!-- main content -->
  <div class="box-root padding-top--24 flex-flex flex-direction--column" style="flex-grow: 1; z-index: 9; width: 100%;">
    <div class="box-root padding-top--48 padding-bottom--24 flex-flex flex-justifyContent--center">
      <h1><a href="#" rel="dofollow">Fee Management System</a></h1>
    </div>
    <div class="formbg-outer">
      <div class="formbg">
        <div class="formbg-inner padding-horizontal--48">
          <span class="padding-bottom--15">Sign in to your account</span>
          
          <!-- Error message -->
          <?php if (isset($error_message)): ?>
            <div class="error-message">
              <?php echo $error_message; ?>
            </div>
          <?php endif; ?>
          
          <form id="stripe-login" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
            <div class="field padding-bottom--24">
              <label for="email">Email</label>
              <input type="email" name="email" id="email" placeholder="you@example.com" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required>
            </div>
            <div class="field padding-bottom--24">
              <div class="grid--50-50">
                <label for="password">Password</label>
                <div class="reset-pass">
                  <a href="#">Forgot your password?</a>
                </div>
              </div>
              <input type="password" name="password" id="password" placeholder="••••••••" required>
            </div>

            <div class="field padding-bottom--24">
              <input type="submit" name="submit" value="Continue">
            </div>

          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Remove JavaScript alert and let PHP handle it -->
<script>
  // Only keep client-side validation
  (function() {
    const form = document.getElementById('stripe-login');
    if (form) {
      form.addEventListener('submit', function(e) {
        const email = document.getElementById('email')?.value || '';
        const pass = document.getElementById('password')?.value || '';
        if (email.trim() === '' || pass.trim() === '') {
          e.preventDefault();
          alert('Please fill in both email and password.');
        }
        // If filled, form will submit normally to PHP
      });
    }
  })();
</script>
</body>
</html> 