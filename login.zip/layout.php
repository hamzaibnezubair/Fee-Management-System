<?php
// layout.php - Main layout wrapper
session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in'])) {
    header("Location: login.php");
    exit();
}

// Get current page name for title
$page_title = isset($page_title) ? $page_title : 'Dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Fee Management System</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* Global Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: #f0f2f5;
            overflow-x: hidden;
        }

        /* Sidebar Styles (same as above - include in a separate CSS file or here) */
        /* ... Include all sidebar styles from above ... */
        
        /* Main Content Area */
        .main-content-wrapper {
            padding: 20px;
            min-height: 100vh;
        }

        .page-header {
            background: white;
            padding: 20px 25px;
            border-radius: 12px;
            margin-bottom: 25px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .page-header h2 {
            font-weight: 700;
            color: #1a1f36;
            margin: 0;
            font-size: 1.5rem;
        }

        .page-header .breadcrumb {
            margin: 0;
            background: transparent;
            padding: 0;
        }

        .page-header .breadcrumb-item a {
            color: #5469d4;
            text-decoration: none;
        }

        .page-header .breadcrumb-item.active {
            color: #6c757d;
        }

        .page-content {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            min-height: 400px;
        }

        /* Responsive */
        @media (max-width: 991.98px) {
            .main-content-wrapper {
                padding: 15px;
                padding-top: 75px;
            }
        }

        @media (max-width: 576px) {
            .main-content-wrapper {
                padding: 10px;
                padding-top: 70px;
            }
            
            .page-header {
                padding: 15px;
            }
            
            .page-content {
                padding: 15px;
            }
        }

        /* Utility Classes */
        .text-primary-custom {
            color: #5469d4 !important;
        }
        .bg-primary-custom {
            background: #5469d4 !important;
        }
        .btn-primary-custom {
            background: #5469d4 !important;
            border-color: #5469d4 !important;
            color: white !important;
        }
        .btn-primary-custom:hover {
            background: #3f55b8 !important;
            border-color: #3f55b8 !important;
        }
        .card-hover {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <!-- Include Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content-wrapper" style="margin-left: 0;">
        <!-- Page Header -->
        <div class="page-header">
            <div>
                <h2><?php echo $page_title; ?></h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo $page_title; ?></li>
                    </ol>
                </nav>
            </div>
            <div>
                <!-- Optional action buttons -->
                <?php if (isset($page_actions)): ?>
                    <?php echo $page_actions; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Page Content -->
        <div class="page-content">
            <?php echo $page_content; ?>
        </div>
    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>