 <?php
// generate_monthly_fee.php - Run this monthly via cron or manually
session_start();
if (!isset($_SESSION['logged_in'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

$current_year = date('Y');
$current_month = date('m');
$academic_year = '2024-2025'; // Get from settings

// Get all active students
$students_query = "SELECT * FROM students WHERE status = 'active'";
$students_result = mysqli_query($conn, $students_query);

$generated = 0;
$skipped = 0;

while($student = mysqli_fetch_assoc($students_result)) {
    // Check if fee already exists for this month
    $check_sql = "SELECT id FROM student_fees 
                  WHERE student_id = '{$student['id']}' 
                  AND month = '$current_month' 
                  AND year = '$current_year' 
                  AND academic_year = '$academic_year'";
    $check_result = mysqli_query($conn, $check_sql);
    
    if (mysqli_num_rows($check_result) == 0) {
        // Get fee structure for this student's class
        $fee_query = "SELECT * FROM fee_structures 
                      WHERE class = '{$student['class']}' 
                      AND academic_year = '$academic_year' 
                      AND status = 'active'";
        $fee_result = mysqli_query($conn, $fee_query);
        
        if ($fee_row = mysqli_fetch_assoc($fee_result)) {
            $due_date = date('Y-m-d', strtotime("$current_year-$current_month-20"));
            
            $insert_sql = "INSERT INTO student_fees (
                student_id, fee_structure_id, month, year, academic_year,
                total_amount, paid_amount, remaining_amount, due_date, status
            ) VALUES (
                '{$student['id']}', '{$fee_row['id']}', '$current_month', '$current_year', '$academic_year',
                '{$fee_row['amount']}', 0, '{$fee_row['amount']}', '$due_date', 'pending'
            )";
            
            if (mysqli_query($conn, $insert_sql)) {
                $generated++;
            }
        } else {
            $skipped++;
        }
    } else {
        $skipped++;
    }
}

echo "✅ Monthly fees generated: $generated<br>";
echo "⏭️ Skipped: $skipped<br>";
?>