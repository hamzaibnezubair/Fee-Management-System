

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fee Management System</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 (for icons) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* ===== GLOBAL STYLES ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: #f0f2f5;
            overflow-x: hidden;
        }

        /* ===== SIDEBAR STYLES ===== */
        .sidebar-wrapper {
            min-height: 100vh;

            background: linear-gradient(180deg, #1a1f36 0%, #2d3561 100%);
            transition: all 0.3s ease;
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            overflow-x: hidden;
            z-index: 1040;
            box-shadow: 4px 0 15px rgba(0, 0, 0, 0.1);
        }

        /* Custom scrollbar for sidebar */
        .sidebar-wrapper::-webkit-scrollbar {
            width: 4px;
        }
        .sidebar-wrapper::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.05);
        }
        .sidebar-wrapper::-webkit-scrollbar-thumb {
            background: #5469d4;
            border-radius: 10px;
        }

        /* Brand/Logo */
        .sidebar-brand {
            padding: 25px 20px 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            text-align: center;
        }

        .sidebar-brand .brand-icon {
            font-size: 2.5rem;
            color: #5469d4;
            background: rgba(84, 105, 212, 0.15);
            width: 60px;
            height: 60px;
            line-height: 60px;
            border-radius: 12px;
            display: inline-block;
            margin-bottom: 10px;
        }

        .sidebar-brand h4 {
            color: #ffffff;
            font-weight: 700;
            font-size: 1.1rem;
            margin: 0;
            letter-spacing: -0.5px;
        }

        .sidebar-brand .subtitle {
            color: rgba(255, 255, 255, 0.5);
            font-size: 0.7rem;
            font-weight: 400;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        /* Navigation Menu */
        .nav-menu {
            padding: 15px 0;
        }

        .nav-menu .nav-section {
            padding: 10px 20px 5px;
            color: rgba(255, 255, 255, 0.3);
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            font-weight: 600;
        }

        .nav-item {
            position: relative;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.6);
            padding: 12px 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
            font-size: 0.9rem;
            font-weight: 500;
            cursor: pointer;
            position: relative;
        }

        .nav-link:hover {
            color: #ffffff;
            background: rgba(84, 105, 212, 0.1);
            border-left-color: #5469d4;
        }

        .nav-link.active {
            color: #ffffff;
            background: rgba(84, 105, 212, 0.15);
            border-left-color: #5469d4;
        }

        .nav-link.active::before {
            content: '';
            position: absolute;
            right: 0;
            top: 0;
            bottom: 0;
            width: 3px;
            background: #5469d4;
            border-radius: 3px 0 0 3px;
        }

        .nav-link i {
            width: 22px;
            font-size: 1.1rem;
            text-align: center;
            color: rgba(255, 255, 255, 0.5);
            transition: all 0.3s ease;
        }

        .nav-link:hover i,
        .nav-link.active i {
            color: #5469d4;
        }

        .nav-link .badge {
            margin-left: auto;
            background: #dc3545;
            color: white;
            padding: 2px 8px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
        }

        /* Sub-menu */
        .sub-menu {
            background: rgba(0, 0, 0, 0.15);
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease, padding 0.3s ease;
            padding: 0;
        }

        .sub-menu.open {
            max-height: 500px;
            padding: 5px 0;
        }

        .sub-menu .nav-link {
            padding: 10px 25px 10px 62px;
            font-size: 0.85rem;
            color: rgba(255, 255, 255, 0.5);
            border-left: 2px solid transparent;
        }

        .sub-menu .nav-link:hover {
            color: #ffffff;
            background: rgba(84, 105, 212, 0.08);
            border-left-color: #5469d4;
        }

        .sub-menu .nav-link.active {
            color: #ffffff;
            background: rgba(84, 105, 212, 0.12);
            border-left-color: #5469d4;
        }

        .sub-menu .nav-link i {
            font-size: 0.8rem;
            width: 18px;
        }

        /* Toggle arrow */
        .nav-link .arrow {
            margin-left: auto;
            transition: transform 0.3s ease;
            font-size: 0.7rem;
            color: rgba(255, 255, 255, 0.3);
        }

        .nav-link .arrow.rotated {
            transform: rotate(90deg);
        }

        /* Divider */
        .nav-divider {
            height: 1px;
            margin: 10px 25px;
            background: rgba(255, 255, 255, 0.06);
        }

        /* Footer */
        .sidebar-footer {
            position: absolute;
            bottom: 20px;
            width: 100%;
            padding: 0 20px;
        }

        .sidebar-footer .user-info {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            padding: 12px 15px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .sidebar-footer .avatar {
            width: 35px;
            height: 35px;
            background: #5469d4;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .sidebar-footer .user-name {
            color: #ffffff;
            font-size: 0.85rem;
            font-weight: 500;
        }

        .sidebar-footer .user-email {
            color: rgba(255, 255, 255, 0.5);
            font-size: 0.7rem;
        }

        .sidebar-footer .logout-btn {
            color: rgba(255, 255, 255, 0.4);
            transition: color 0.3s ease;
            margin-left: auto;
        }

        .sidebar-footer .logout-btn:hover {
            color: #dc3545;
        }

        /* ===== MAIN CONTENT AREA ===== */
        .main-content-wrapper {
            padding: 20px;
            min-height: 100vh;
        }

        /* ===== MOBILE TOGGLE BUTTON ===== */
        .mobile-toggle {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1050;
            background: #1a1f36;
            color: white;
            border: none;
            padding: 12px 14px;
            border-radius: 10px;
            font-size: 1.3rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }

        .mobile-toggle:hover {
            background: #2d3561;
            transform: scale(1.05);
        }

        /* ===== OVERLAY FOR MOBILE ===== */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1030;
        }

        .sidebar-overlay.show {
            display: block;
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width: 991.98px) {
            .sidebar-wrapper {
                position: fixed;
                left: -100%;
                top: 0;
                bottom: 0;
                width: 280px;
                transition: left 0.3s ease;
                height: 100vh;
                border-radius: 0;
            }

            .sidebar-wrapper.show {
                left: 0;
            }

            .mobile-toggle {
                display: block;
            }

            .main-content-wrapper {
                padding-top: 20px;
            }

            .sidebar-footer {
                position: relative;
                bottom: auto;
                margin-top: 20px;
                padding: 20px 20px 10px;
            }
        }

        @media (max-width: 576px) {
            .sidebar-wrapper {
                width: 280px;
            }

            .main-content-wrapper {
                padding: 15px;
            }
        }

        /* ===== ANIMATIONS ===== */
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .nav-item {
            animation: slideIn 0.3s ease forwards;
            opacity: 0;
        }

        .nav-item:nth-child(1) { animation-delay: 0.05s; }
        .nav-item:nth-child(2) { animation-delay: 0.1s; }
        .nav-item:nth-child(3) { animation-delay: 0.15s; }
        .nav-item:nth-child(4) { animation-delay: 0.2s; }
        .nav-item:nth-child(5) { animation-delay: 0.25s; }
        .nav-item:nth-child(6) { animation-delay: 0.3s; }
        .nav-item:nth-child(7) { animation-delay: 0.35s; }
        .nav-item:nth-child(8) { animation-delay: 0.4s; }
        .nav-item:nth-child(9) { animation-delay: 0.45s; }

        /* Active page indicator */
        .page-indicator {
            background: #5469d4;
            color: white;
            padding: 8px 20px;
            border-radius: 8px;
            font-weight: 500;
            font-size: 0.85rem;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .page-indicator i {
            font-size: 1rem;
        }
    </style>
</head>
<body>
    <!-- Mobile Toggle Button -->
    <button class="mobile-toggle" id="sidebarToggle" aria-label="Toggle Sidebar">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- ===== SIDEBAR ===== -->
    <div class="sidebar-wrapper" id="sidebar">
        <!-- Brand -->
        <div class="sidebar-brand">
            <div class="brand-icon">
                <i class="fas fa-graduation-cap"></i>
            </div>
            <h4>Fee Management</h4>
            <div class="subtitle">System v2.0</div>
        </div>

        <!-- Navigation Menu -->
        <div class="nav-menu">
            <!-- Dashboard -->
            <div class="nav-item">
                <a href="dashboard.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                    <i class="fas fa-th-large"></i>
                    <span>Dashboard</span>
                </a>
            </div>

            <div class="nav-divider"></div>

            <!-- Student Management -->
            <div class="nav-section">Student Management</div>
            <div class="nav-item">
                <a href="add_student.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'add_student.php' ? 'active' : ''; ?>">
                    <i class="fas fa-user-plus"></i>
                    <span>Add Student</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="view_students.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'view_students.php' ? 'active' : ''; ?>">
                    <i class="fas fa-users"></i>
                    <span>View Students</span>
                </a>
            </div>

            <div class="nav-divider"></div>

            <!-- Fee Management -->
            <div class="nav-section">Fee Management</div>
            <div class="nav-item">
                <a href="#" class="nav-link" onclick="toggleSubMenu(event, 'feeManagement')">
                    <i class="fas fa-coins"></i>
                    <span>Fee Management</span>
                    <span class="arrow" id="feeManagementArrow"><i class="fas fa-chevron-right"></i></span>
                </a>
                <div class="sub-menu" id="feeManagement">
                    <a href="add_fee.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'add_fee.php' ? 'active' : ''; ?>">
                        <i class="fas fa-plus-circle"></i> Add Fee
                    </a>
                    <a href="view_fee.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'view_fee.php' ? 'active' : ''; ?>">
                        <i class="fas fa-eye"></i> View Fee
                    </a>
                    <a href="set_fee.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'set_fee.php' ? 'active' : ''; ?>">
                        <i class="fas fa-sliders-h"></i> Set Fee
                    </a>
                    <a href="view_pending_fee.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'view_pending_fee.php' ? 'active' : ''; ?>">
                        <i class="fas fa-clock"></i> View Pending Fee
                        <span class="badge">12</span>
                    </a>
                    <a href="view_paid_fee.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'view_paid_fee.php' ? 'active' : ''; ?>">
                        <i class="fas fa-check-circle"></i> View Paid Fee
                    </a>
                    <a href="payment_history.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'payment_history.php' ? 'active' : ''; ?>">
                        <i class="fas fa-history"></i> Payment History
                    </a>
                    <a href="fee_challan.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'fee_challan.php' ? 'active' : ''; ?>">
                        <i class="fas fa-file-invoice"></i> Fee Challan
                    </a>
                </div>
            </div>

            <div class="nav-divider"></div>

            <!-- Fee Processing -->
            <div class="nav-section">Fee Processing</div>
            <div class="nav-item">
                <a href="#" class="nav-link" onclick="toggleSubMenu(event, 'feeProcessing')">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Fee Processing</span>
                    <span class="arrow" id="feeProcessingArrow"><i class="fas fa-chevron-right"></i></span>
                </a>
                <div class="sub-menu" id="feeProcessing">
                    <a href="collect_fee.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'collect_fee.php' ? 'active' : ''; ?>">
                        <i class="fas fa-hand-holding-heart"></i> Collect Fee
                    </a>
                    <a href="payment_history.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'payment_history.php' ? 'active' : ''; ?>">
                        <i class="fas fa-receipt"></i> Payment History
                    </a>
                </div>
            </div>

            <div class="nav-divider"></div>

            <!-- Reports -->
            <div class="nav-section">Reports</div>
            <div class="nav-item">
                <a href="reports.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : ''; ?>">
                    <i class="fas fa-chart-bar"></i>
                    <span>Reports</span>
                </a>
            </div>

            <div class="nav-divider"></div>

            <!-- Settings -->
            <div class="nav-section">System</div>
            <div class="nav-item">
                <a href="settings.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
            </div>
        </div>

        <!-- Sidebar Footer with User Info -->
        <div class="sidebar-footer">
            <div class="user-info">
                <div class="avatar">H</div>
                <div>
                    <div class="user-name">Hamza Ahmed</div>
                    <div class="user-email">admin@feesystem.com</div>
                </div>
                <a href="logout.php" class="logout-btn" title="Logout">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // ===== TOGGLE SUB-MENU =====
        function toggleSubMenu(event, menuId) {
            event.preventDefault();
            
            const menu = document.getElementById(menuId);
            const arrow = document.getElementById(menuId + 'Arrow');
            
            if (!menu) return;
            
            // Close other sub-menus
            const allSubMenus = document.querySelectorAll('.sub-menu');
            allSubMenus.forEach(sub => {
                if (sub.id !== menuId && sub.classList.contains('open')) {
                    sub.classList.remove('open');
                    const otherArrow = document.getElementById(sub.id + 'Arrow');
                    if (otherArrow) otherArrow.classList.remove('rotated');
                }
            });
            
            // Toggle current
            menu.classList.toggle('open');
            if (arrow) {
                arrow.classList.toggle('rotated');
            }
            
            // Update arrow rotation for all
            document.querySelectorAll('.sub-menu.open').forEach(openMenu => {
                const arrowId = openMenu.id + 'Arrow';
                const arrowEl = document.getElementById(arrowId);
                if (arrowEl) arrowEl.classList.add('rotated');
            });
        }

        // ===== SIDEBAR TOGGLE (Mobile) =====
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const toggleBtn = document.getElementById('sidebarToggle');
            const overlay = document.getElementById('sidebarOverlay');

            function toggleSidebar() {
                sidebar.classList.toggle('show');
                overlay.classList.toggle('show');
                document.body.style.overflow = sidebar.classList.contains('show') ? 'hidden' : '';
            }

            if (toggleBtn) {
                toggleBtn.addEventListener('click', toggleSidebar);
            }

            if (overlay) {
                overlay.addEventListener('click', toggleSidebar);
            }

            // Close sidebar on ESC key
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && sidebar.classList.contains('show')) {
                    toggleSidebar();
                }
            });

            // Auto-open sub-menu based on active page
            const activeLinks = document.querySelectorAll('.sub-menu .nav-link.active');
            activeLinks.forEach(link => {
                const parentSub = link.closest('.sub-menu');
                if (parentSub) {
                    parentSub.classList.add('open');
                    const arrowId = parentSub.id + 'Arrow';
                    const arrowEl = document.getElementById(arrowId);
                    if (arrowEl) arrowEl.classList.add('rotated');
                }
            });

            // Set active parent menu
            document.querySelectorAll('.nav-link').forEach(link => {
                if (link.classList.contains('active')) {
                    const parentItem = link.closest('.nav-item');
                    if (parentItem) {
                        // Keep it active
                    }
                }
            });
        });

        // ===== CLOSE SIDEBAR ON RESIZE =====
        window.addEventListener('resize', function() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            if (window.innerWidth >= 992 && sidebar.classList.contains('show')) {
                sidebar.classList.remove('show');
                overlay.classList.remove('show');
                document.body.style.overflow = '';
            }
        });
    </script>
</body>
</html>