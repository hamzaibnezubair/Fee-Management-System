<?php
// dashboard_content.php - Dashboard with Charts and Statistics

// Get current academic year
$current_year_query = "SELECT * FROM academic_years WHERE is_current = 1 AND status = 'active'";
$current_year_result = mysqli_query($conn, $current_year_query);
$current_year = mysqli_fetch_assoc($current_year_result);
$academic_year_id = $current_year ? $current_year['id'] : 1;
$academic_year_name = $current_year ? $current_year['year_name'] : '2024-2025';

// Get filter parameters
$filter_month = isset($_GET['filter_month']) ? (int)$_GET['filter_month'] : date('m');
$filter_year = isset($_GET['filter_year']) ? (int)$_GET['filter_year'] : date('Y');

// ===== STATISTICS =====
// 1. Total Students
$total_students_query = "SELECT COUNT(*) as total FROM students WHERE status = 'active'";
$total_students_result = mysqli_query($conn, $total_students_query);
$total_students = mysqli_fetch_assoc($total_students_result)['total'];

// 2. Total Collected (All time)
$total_collected_query = "SELECT SUM(amount) as total FROM payments WHERE status = 'completed'";
$total_collected_result = mysqli_query($conn, $total_collected_query);
$total_collected = mysqli_fetch_assoc($total_collected_result)['total'] ?? 0;

// 3. Total Pending (All time)
$total_pending_query = "SELECT SUM(remaining_amount) as total FROM student_fees WHERE status IN ('pending', 'partial', 'overdue')";
$total_pending_result = mysqli_query($conn, $total_pending_query);
$total_pending = mysqli_fetch_assoc($total_pending_result)['total'] ?? 0;

// 4. Current Month Collection
$current_month_collection_query = "SELECT SUM(amount) as total FROM payments 
                                   WHERE MONTH(payment_date) = '$filter_month' 
                                   AND YEAR(payment_date) = '$filter_year' 
                                   AND status = 'completed'";
$current_month_collection_result = mysqli_query($conn, $current_month_collection_query);
$current_month_collection = mysqli_fetch_assoc($current_month_collection_result)['total'] ?? 0;

// 5. Current Month Pending
$current_month_pending_query = "SELECT SUM(remaining_amount) as total FROM student_fees 
                                WHERE month = '$filter_month' 
                                AND year = '$filter_year' 
                                AND status IN ('pending', 'partial', 'overdue')";
$current_month_pending_result = mysqli_query($conn, $current_month_pending_query);
$current_month_pending = mysqli_fetch_assoc($current_month_pending_result)['total'] ?? 0;

// 6. Students with 3+ months pending
$three_months_pending_query = "SELECT s.id, s.student_id, s.first_name, s.last_name, s.class, s.fee,
                               COUNT(sf.id) as pending_months,
                               SUM(sf.remaining_amount) as total_pending
                               FROM students s
                               JOIN student_fees sf ON s.id = sf.student_id
                               WHERE s.status = 'active' 
                               AND sf.academic_year_id = '$academic_year_id'
                               AND sf.status IN ('pending', 'partial', 'overdue')
                               GROUP BY s.id
                               HAVING pending_months >= 3
                               ORDER BY pending_months DESC";
$three_months_pending_result = mysqli_query($conn, $three_months_pending_query);

// 7. Monthly Collection Data (Last 12 months)
$monthly_collection_data = [];
for ($i = 11; $i >= 0; $i--) {
    $month = date('m', strtotime("-$i months"));
    $year = date('Y', strtotime("-$i months"));
    $month_name = date('M', strtotime("-$i months"));
    
    $query = "SELECT SUM(amount) as total FROM payments 
              WHERE MONTH(payment_date) = '$month' 
              AND YEAR(payment_date) = '$year' 
              AND status = 'completed'";
    $result = mysqli_query($conn, $query);
    $amount = mysqli_fetch_assoc($result)['total'] ?? 0;
    
    $monthly_collection_data[] = [
        'month' => $month_name . ' ' . $year,
        'amount' => (float)$amount
    ];
}

// 8. Class-wise Student Distribution
$class_distribution_query = "SELECT class, COUNT(*) as count FROM students WHERE status = 'active' GROUP BY class ORDER BY class";
$class_distribution_result = mysqli_query($conn, $class_distribution_query);
$class_distribution = [];
while($row = mysqli_fetch_assoc($class_distribution_result)) {
    $class_distribution[] = $row;
}

// 9. Payment Method Distribution
$payment_method_query = "SELECT payment_method, COUNT(*) as count, SUM(amount) as total 
                         FROM payments WHERE status = 'completed' 
                         GROUP BY payment_method";
$payment_method_result = mysqli_query($conn, $payment_method_query);
$payment_methods = [];
while($row = mysqli_fetch_assoc($payment_method_result)) {
    $payment_methods[] = $row;
}

// 10. Recent Payments
$recent_payments_query = "SELECT p.*, s.first_name, s.last_name, s.student_id 
                          FROM payments p 
                          JOIN students s ON p.student_id = s.id 
                          WHERE p.status = 'completed' 
                          ORDER BY p.payment_date DESC LIMIT 10";
$recent_payments_result = mysqli_query($conn, $recent_payments_query);

// 11. Month-wise Collection for selected year
$yearly_collection = [];
for ($m = 1; $m <= 12; $m++) {
    $query = "SELECT SUM(amount) as total FROM payments 
              WHERE MONTH(payment_date) = '$m' 
              AND YEAR(payment_date) = '$filter_year' 
              AND status = 'completed'";
    $result = mysqli_query($conn, $query);
    $amount = mysqli_fetch_assoc($result)['total'] ?? 0;
    $yearly_collection[] = [
        'month' => date('M', mktime(0,0,0,$m,1)),
        'amount' => (float)$amount
    ];
}

// 12. Fee Status Summary for current month
$fee_status_query = "SELECT 
                      COUNT(CASE WHEN sf.status = 'paid' THEN 1 END) as paid,
                      COUNT(CASE WHEN sf.status = 'partial' THEN 1 END) as partial,
                      COUNT(CASE WHEN sf.status = 'pending' THEN 1 END) as pending,
                      COUNT(CASE WHEN sf.status = 'overdue' THEN 1 END) as overdue
                      FROM student_fees sf
                      WHERE sf.month = '$filter_month' 
                      AND sf.year = '$filter_year'
                      AND sf.academic_year_id = '$academic_year_id'";
$fee_status_result = mysqli_query($conn, $fee_status_query);
$fee_status = mysqli_fetch_assoc($fee_status_result);
?>
<!DOCTYPE html>
<html>
<head>
    <!-- Chart.js for graphs -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    
    <style>
        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-box {
            background: white;
            padding: 20px 25px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border-left: 4px solid #5469d4;
            transition: all 0.3s ease;
        }
        
        .stat-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .stat-box .stat-icon {
            font-size: 1.8rem;
            margin-bottom: 8px;
        }
        
        .stat-box .stat-label {
            font-size: 0.8rem;
            color: #6c757d;
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        
        .stat-box .stat-value {
            font-size: 1.8rem;
            font-weight: 700;
            color: #1a1f36;
        }
        
        .stat-box .stat-sub {
            font-size: 0.8rem;
            color: #6c757d;
            margin-top: 5px;
        }
        
        .stat-box.green { border-left-color: #28a745; }
        .stat-box.blue { border-left-color: #5469d4; }
        .stat-box.orange { border-left-color: #fd7e14; }
        .stat-box.red { border-left-color: #dc3545; }
        .stat-box.purple { border-left-color: #6f42c1; }
        .stat-box.teal { border-left-color: #20c997; }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 25px;
            margin-bottom: 30px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .dashboard-card .card-title {
            font-size: 1rem;
            font-weight: 600;
            color: #1a1f36;
            margin-bottom: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .dashboard-card .card-title .badge-count {
            background: #5469d4;
            color: white;
            padding: 2px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
        }
        
        .chart-container {
            position: relative;
            height: 280px;
        }
        
        .filter-section {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
            margin-bottom: 20px;
            padding: 15px 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .filter-section label {
            font-weight: 600;
            font-size: 0.9rem;
            color: #1a1f36;
            margin: 0;
        }
        
        .filter-section select {
            padding: 8px 14px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 0.9rem;
            background: white;
            transition: all 0.3s ease;
        }
        
        .filter-section select:focus {
            outline: none;
            border-color: #5469d4;
        }
        
        .filter-section .btn-filter {
            background: #5469d4;
            color: white;
            padding: 8px 25px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .filter-section .btn-filter:hover {
            background: #3f55b8;
        }
        
        .pending-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.85rem;
        }
        
        .pending-table th {
            background: #f8f9fa;
            padding: 10px 12px;
            text-align: left;
            border-bottom: 2px solid #e9ecef;
            font-weight: 600;
        }
        
        .pending-table td {
            padding: 10px 12px;
            border-bottom: 1px solid #e9ecef;
        }
        
        .pending-table tr:hover {
            background: #f8f9fa;
        }
        
        .pending-badge {
            background: #dc3545;
            color: white;
            padding: 2px 10px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        
        .status-badge {
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
            display: inline-block;
        }
        
        .status-badge.paid { background: #d4edda; color: #155724; }
        .status-badge.pending { background: #fff3cd; color: #856404; }
        .status-badge.partial { background: #cce5ff; color: #004085; }
        .status-badge.overdue { background: #f8d7da; color: #721c24; }
        
        .recent-payments-list {
            max-height: 400px;
            overflow-y: auto;
        }
        
        .recent-payments-list::-webkit-scrollbar {
            width: 4px;
        }
        .recent-payments-list::-webkit-scrollbar-thumb {
            background: #5469d4;
            border-radius: 10px;
        }
        
        .payment-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #f0f2f5;
        }
        
        .payment-item:last-child {
            border-bottom: none;
        }
        
        .payment-item .student-name {
            font-weight: 600;
            color: #1a1f36;
        }
        
        .payment-item .student-id {
            font-size: 0.75rem;
            color: #6c757d;
        }
        
        .payment-item .amount {
            font-weight: 700;
            color: #28a745;
        }
        
        .payment-item .date {
            font-size: 0.75rem;
            color: #6c757d;
        }
        
        .payment-method-badge {
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.65rem;
            background: #e9ecef;
            color: #495057;
        }
        
        .btn-view-all {
            color: #5469d4;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.85rem;
        }
        
        .btn-view-all:hover {
            text-decoration: underline;
        }
        
        .no-data {
            text-align: center;
            padding: 30px;
            color: #6c757d;
        }
        
        .no-data .icon {
            font-size: 3rem;
            opacity: 0.3;
            margin-bottom: 10px;
        }
        
        @media (max-width: 992px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
            
            .dashboard-stats {
                grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            }
        }
        
        @media (max-width: 576px) {
            .dashboard-stats {
                grid-template-columns: 1fr 1fr;
                gap: 10px;
            }
            
            .stat-box {
                padding: 15px;
            }
            
            .stat-box .stat-value {
                font-size: 1.3rem;
            }
            
            .filter-section {
                flex-direction: column;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>
    <!-- ===== FILTER SECTION ===== -->
    <div class="filter-section">
        <label>📅 Filter by Month:</label>
        <select name="filter_month" id="filterMonth">
            <option value="1" <?php echo $filter_month == 1 ? 'selected' : ''; ?>>January</option>
            <option value="2" <?php echo $filter_month == 2 ? 'selected' : ''; ?>>February</option>
            <option value="3" <?php echo $filter_month == 3 ? 'selected' : ''; ?>>March</option>
            <option value="4" <?php echo $filter_month == 4 ? 'selected' : ''; ?>>April</option>
            <option value="5" <?php echo $filter_month == 5 ? 'selected' : ''; ?>>May</option>
            <option value="6" <?php echo $filter_month == 6 ? 'selected' : ''; ?>>June</option>
            <option value="7" <?php echo $filter_month == 7 ? 'selected' : ''; ?>>July</option>
            <option value="8" <?php echo $filter_month == 8 ? 'selected' : ''; ?>>August</option>
            <option value="9" <?php echo $filter_month == 9 ? 'selected' : ''; ?>>September</option>
            <option value="10" <?php echo $filter_month == 10 ? 'selected' : ''; ?>>October</option>
            <option value="11" <?php echo $filter_month == 11 ? 'selected' : ''; ?>>November</option>
            <option value="12" <?php echo $filter_month == 12 ? 'selected' : ''; ?>>December</option>
        </select>
        
        <select name="filter_year" id="filterYear">
            <option value="<?php echo date('Y'); ?>" <?php echo $filter_year == date('Y') ? 'selected' : ''; ?>><?php echo date('Y'); ?></option>
            <option value="<?php echo date('Y')-1; ?>" <?php echo $filter_year == date('Y')-1 ? 'selected' : ''; ?>><?php echo date('Y')-1; ?></option>
            <option value="<?php echo date('Y')-2; ?>" <?php echo $filter_year == date('Y')-2 ? 'selected' : ''; ?>><?php echo date('Y')-2; ?></option>
        </select>
        
        <button class="btn-filter" onclick="applyFilter()">Apply Filter</button>
        <span style="font-size: 0.85rem; color: #6c757d; margin-left: auto;">
            Showing data for: <strong><?php echo date('F', mktime(0,0,0,$filter_month,1)) . ' ' . $filter_year; ?></strong>
        </span>
    </div>
    
    <!-- ===== STATISTICS CARDS ===== -->
    <div class="dashboard-stats">
        <div class="stat-box blue">
            <div class="stat-icon">👨‍🎓</div>
            <div class="stat-label">Total Students</div>
            <div class="stat-value"><?php echo $total_students; ?></div>
            <div class="stat-sub">Active students</div>
        </div>
        
        <div class="stat-box green">
            <div class="stat-icon">💰</div>
            <div class="stat-label">Total Collected</div>
            <div class="stat-value">₹<?php echo number_format($total_collected, 2); ?></div>
            <div class="stat-sub">All time collection</div>
        </div>
        
        <div class="stat-box orange">
            <div class="stat-icon">📊</div>
            <div class="stat-label">This Month Collected</div>
            <div class="stat-value">₹<?php echo number_format($current_month_collection, 2); ?></div>
            <div class="stat-sub"><?php echo date('F Y', mktime(0,0,0,$filter_month,1,$filter_year)); ?></div>
        </div>
        
        <div class="stat-box red">
            <div class="stat-icon">⏳</div>
            <div class="stat-label">This Month Pending</div>
            <div class="stat-value">₹<?php echo number_format($current_month_pending, 2); ?></div>
            <div class="stat-sub"><?php echo date('F Y', mktime(0,0,0,$filter_month,1,$filter_year)); ?></div>
        </div>
        
        <div class="stat-box purple">
            <div class="stat-icon">📈</div>
            <div class="stat-label">Collection Rate</div>
            <?php 
            $total_for_month = $current_month_collection + $current_month_pending;
            $collection_rate = $total_for_month > 0 ? ($current_month_collection / $total_for_month) * 100 : 0;
            ?>
            <div class="stat-value"><?php echo number_format($collection_rate, 1); ?>%</div>
            <div class="stat-sub"><?php echo date('F Y', mktime(0,0,0,$filter_month,1,$filter_year)); ?></div>
        </div>
        
        <div class="stat-box teal">
            <div class="stat-icon">🏷️</div>
            <div class="stat-label">Total Pending</div>
            <div class="stat-value">₹<?php echo number_format($total_pending, 2); ?></div>
            <div class="stat-sub">All time pending</div>
        </div>
    </div>
    
    <!-- ===== DASHBOARD GRID ===== -->
    <div class="dashboard-grid">
        <!-- Monthly Collection Chart -->
        <div class="dashboard-card">
            <div class="card-title">
                <span>📊 Monthly Collection Trend</span>
                <span class="badge-count">Last 12 months</span>
            </div>
            <div class="chart-container">
                <canvas id="monthlyChart"></canvas>
            </div>
        </div>
        
        <!-- Class Distribution Chart -->
        <div class="dashboard-card">
            <div class="card-title">
                <span>📚 Class Distribution</span>
                <span class="badge-count"><?php echo count($class_distribution); ?> classes</span>
            </div>
            <div class="chart-container">
                <canvas id="classChart"></canvas>
            </div>
        </div>
    </div>
    
    <!-- ===== SECOND ROW ===== -->
    <div class="dashboard-grid">
        <!-- Fee Status for Current Month -->
        <div class="dashboard-card">
            <div class="card-title">
                <span>📋 Fee Status - <?php echo date('F Y', mktime(0,0,0,$filter_month,1,$filter_year)); ?></span>
            </div>
            <div style="height: 250px;">
                <canvas id="feeStatusChart"></canvas>
            </div>
        </div>
        
        <!-- Payment Methods -->
        <div class="dashboard-card">
            <div class="card-title">
                <span>💳 Payment Methods</span>
                <span class="badge-count"><?php echo count($payment_methods); ?> methods</span>
            </div>
            <div style="height: 250px;">
                <canvas id="paymentMethodChart"></canvas>
            </div>
        </div>
    </div>
    
    <!-- ===== YEARLY COLLECTION CHART ===== -->
    <div class="dashboard-card" style="margin-bottom: 30px;">
        <div class="card-title">
            <span>📈 Yearly Collection - <?php echo $filter_year; ?></span>
            <span class="badge-count">Monthly breakdown</span>
        </div>
        <div class="chart-container" style="height: 250px;">
            <canvas id="yearlyChart"></canvas>
        </div>
    </div>
    
    <!-- ===== THREE MONTHS PENDING STUDENTS ===== -->
    <div class="dashboard-card" style="margin-bottom: 30px;">
        <div class="card-title">
            <span>⚠️ Students with 3+ Months Pending</span>
            <span class="badge-count" style="background: #dc3545;">
                <?php echo mysqli_num_rows($three_months_pending_result); ?> students
            </span>
        </div>
        
        <?php if (mysqli_num_rows($three_months_pending_result) > 0): ?>
            <div class="table-responsive">
                <table class="pending-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Class</th>
                            <th>Monthly Fee</th>
                            <th>Pending Months</th>
                            <th>Total Pending</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $count = 1; ?>
                        <?php while($student = mysqli_fetch_assoc($three_months_pending_result)): ?>
                            <tr>
                                <td><?php echo $count++; ?></td>
                                <td><strong><?php echo htmlspecialchars($student['student_id']); ?></strong></td>
                                <td><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></td>
                                <td>Class <?php echo htmlspecialchars($student['class']); ?></td>
                                <td>₹<?php echo number_format($student['fee'], 2); ?></td>
                                <td><span class="pending-badge"><?php echo $student['pending_months']; ?> months</span></td>
                                <td style="color: #dc3545; font-weight: 600;">
                                    ₹<?php echo number_format($student['total_pending'], 2); ?>
                                </td>
                                <td>
                                    <a href="dashboard.php?page=fee_management&view_student=<?php echo $student['id']; ?>" class="btn-view" style="font-size: 0.8rem;">
                                        👁️ View
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="no-data">
                <div class="icon">🎉</div>
                <p>No students with 3+ months pending! All caught up!</p>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- ===== RECENT PAYMENTS ===== -->
    <div class="dashboard-card">
        <div class="card-title">
            <span>🔄 Recent Payments</span>
            <a href="dashboard.php?page=payment_history" class="btn-view-all">View All →</a>
        </div>
        
        <?php if (mysqli_num_rows($recent_payments_result) > 0): ?>
            <div class="recent-payments-list">
                <?php while($payment = mysqli_fetch_assoc($recent_payments_result)): ?>
                    <div class="payment-item">
                        <div>
                            <div class="student-name">
                                <?php echo htmlspecialchars($payment['first_name'] . ' ' . $payment['last_name']); ?>
                            </div>
                            <div class="student-id">
                                <?php echo htmlspecialchars($payment['student_id']); ?> • 
                                <span class="payment-method-badge"><?php echo ucfirst($payment['payment_method']); ?></span>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <div class="amount">+₹<?php echo number_format($payment['amount'], 2); ?></div>
                            <div class="date"><?php echo date('d-M-Y', strtotime($payment['payment_date'])); ?></div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="no-data">
                <div class="icon">📭</div>
                <p>No recent payments found.</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- ===== CHARTS JAVASCRIPT ===== -->
    <script>
    // ===== APPLY FILTER =====
    function applyFilter() {
        const month = document.getElementById('filterMonth').value;
        const year = document.getElementById('filterYear').value;
        window.location.href = 'dashboard.php?page=dashboard&filter_month=' + month + '&filter_year=' + year;
    }
    
    // ===== INITIALIZE CHARTS =====
    document.addEventListener('DOMContentLoaded', function() {
        // 1. Monthly Collection Chart
        const monthlyCtx = document.getElementById('monthlyChart').getContext('2d');
        const monthlyData = <?php echo json_encode($monthly_collection_data); ?>;
        new Chart(monthlyCtx, {
            type: 'bar',
            data: {
                labels: monthlyData.map(d => d.month),
                datasets: [{
                    label: 'Collection (₹)',
                    data: monthlyData.map(d => d.amount),
                    backgroundColor: 'rgba(84, 105, 212, 0.7)',
                    borderColor: 'rgba(84, 105, 212, 1)',
                    borderWidth: 2,
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₹' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
        
        // 2. Class Distribution Chart
        const classCtx = document.getElementById('classChart').getContext('2d');
        const classData = <?php echo json_encode($class_distribution); ?>;
        const classColors = ['#5469d4', '#28a745', '#fd7e14', '#dc3545', '#6f42c1', '#20c997', '#ffc107', '#17a2b8', '#e83e8c', '#6c757d'];
        new Chart(classCtx, {
            type: 'doughnut',
            data: {
                labels: classData.map(d => d.class),
                datasets: [{
                    data: classData.map(d => d.count),
                    backgroundColor: classColors.slice(0, classData.length),
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            font: {
                                size: 10
                            }
                        }
                    }
                }
            }
        });
        
        // 3. Fee Status Chart
        const statusCtx = document.getElementById('feeStatusChart').getContext('2d');
        const statusData = <?php echo json_encode($fee_status); ?>;
        new Chart(statusCtx, {
            type: 'bar',
            data: {
                labels: ['Paid', 'Partial', 'Pending', 'Overdue'],
                datasets: [{
                    label: 'Students',
                    data: [statusData.paid || 0, statusData.partial || 0, statusData.pending || 0, statusData.overdue || 0],
                    backgroundColor: ['#28a745', '#ffc107', '#fd7e14', '#dc3545'],
                    borderColor: ['#28a745', '#ffc107', '#fd7e14', '#dc3545'],
                    borderWidth: 2,
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });
        
        // 4. Payment Methods Chart
        const methodCtx = document.getElementById('paymentMethodChart').getContext('2d');
        const methodData = <?php echo json_encode($payment_methods); ?>;
        const methodColors = ['#5469d4', '#28a745', '#fd7e14', '#6f42c1', '#20c997'];
        new Chart(methodCtx, {
            type: 'pie',
            data: {
                labels: methodData.map(d => d.payment_method.charAt(0).toUpperCase() + d.payment_method.slice(1)),
                datasets: [{
                    data: methodData.map(d => d.total),
                    backgroundColor: methodColors.slice(0, methodData.length),
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            font: {
                                size: 10
                            }
                        }
                    }
                }
            }
        });
        
        // 5. Yearly Collection Chart
        const yearlyCtx = document.getElementById('yearlyChart').getContext('2d');
        const yearlyData = <?php echo json_encode($yearly_collection); ?>;
        new Chart(yearlyCtx, {
            type: 'line',
            data: {
                labels: yearlyData.map(d => d.month),
                datasets: [{
                    label: 'Collection (₹)',
                    data: yearlyData.map(d => d.amount),
                    backgroundColor: 'rgba(84, 105, 212, 0.1)',
                    borderColor: 'rgba(84, 105, 212, 1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: 'rgba(84, 105, 212, 1)',
                    pointRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₹' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    });
    </script>
</body>
</html>